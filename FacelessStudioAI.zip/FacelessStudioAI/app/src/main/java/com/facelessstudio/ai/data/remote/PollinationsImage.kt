package com.facelessstudio.ai.data.remote

/**
 * Pollinations.ai — completely free, no API key, no sign-up, no rate-limit gate.
 * It works as a plain image URL: requesting the URL directly returns the generated
 * image, so no Retrofit call is even needed — Coil can load it like any other image.
 *
 * Usage: PollinationsImage.urlFor("a neon cyberpunk city at night")
 */
object PollinationsImage {
    private const val BASE = "https://image.pollinations.ai/prompt/"

    fun urlFor(prompt: String, width: Int = 1024, height: Int = 1024, seed: Long? = null): String {
        val encoded = java.net.URLEncoder.encode(prompt, "UTF-8")
        val seedParam = seed?.let { "&seed=$it" } ?: ""
        return "$BASE$encoded?width=$width&height=$height&nologo=true$seedParam"
    }
}
