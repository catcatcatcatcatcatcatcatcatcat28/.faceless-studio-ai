package com.facelessstudio.ai.data.repository

import com.facelessstudio.ai.domain.model.SocialPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

data class ManagedPage(
    val id: String,
    val name: String,
    val pageAccessToken: String,
    val instagramBusinessAccountId: String?
)

/**
 * A Facebook user can manage multiple Pages, and posting requires a
 * *Page* access token (not the user's own token) plus the specific Page ID.
 * Instagram publishing rides on that same Page token, via the Page's linked
 * Instagram Business Account.
 */
@Singleton
class MetaPageRepository @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val oauthRepository: OAuthRepository,
    private val credentialsRepository: OAuthCredentialsRepository
) {
    suspend fun fetchManagedPages(): Result<List<ManagedPage>> = withContext(Dispatchers.IO) {
        try {
            val userToken = oauthRepository.validAccessToken(SocialPlatform.FACEBOOK)
                ?: return@withContext Result.failure(IllegalStateException("Not connected to Facebook."))

            val url = "https://graph.facebook.com/v19.0/me/accounts" +
                "?fields=id,name,access_token,instagram_business_account" +
                "&access_token=$userToken"
            val request = Request.Builder().url(url).build()

            okHttpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Could not list Facebook Pages (HTTP ${response.code}): $body"))
                }
                val data = JSONObject(body).getJSONArray("data")
                val pages = (0 until data.length()).map { i ->
                    val page = data.getJSONObject(i)
                    ManagedPage(
                        id = page.getString("id"),
                        name = page.getString("name"),
                        pageAccessToken = page.getString("access_token"),
                        instagramBusinessAccountId = page.optJSONObject("instagram_business_account")?.optString("id")
                    )
                }
                Result.success(pages)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun selectPage(page: ManagedPage) {
        credentialsRepository.saveExtra(SocialPlatform.FACEBOOK, "page_id", page.id)
        credentialsRepository.saveExtra(SocialPlatform.FACEBOOK, "page_name", page.name)
        credentialsRepository.saveExtra(SocialPlatform.FACEBOOK, "page_token", page.pageAccessToken)
        page.instagramBusinessAccountId?.let {
            credentialsRepository.saveExtra(SocialPlatform.INSTAGRAM, "ig_business_id", it)
            credentialsRepository.saveExtra(SocialPlatform.INSTAGRAM, "page_token", page.pageAccessToken)
        }
    }

    fun selectedPageName(): String? = credentialsRepository.extra(SocialPlatform.FACEBOOK, "page_name")
    fun selectedPageId(): String? = credentialsRepository.extra(SocialPlatform.FACEBOOK, "page_id")
    fun selectedPageToken(): String? = credentialsRepository.extra(SocialPlatform.FACEBOOK, "page_token")
    fun linkedInstagramBusinessId(): String? = credentialsRepository.extra(SocialPlatform.INSTAGRAM, "ig_business_id")
    fun instagramPageToken(): String? = credentialsRepository.extra(SocialPlatform.INSTAGRAM, "page_token")
}
