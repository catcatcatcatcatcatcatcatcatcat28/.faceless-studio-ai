package com.facelessstudio.ai.ui.screens.create

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import coil.compose.AsyncImage
import com.facelessstudio.ai.data.repository.VideoOutputUtils
import com.facelessstudio.ai.ui.theme.NeonBlue
import com.facelessstudio.ai.ui.theme.SuccessGreen

@Composable
fun CreateVideoScreen(
    prefillTopic: String? = null,
    onOpenApiKeySettings: () -> Unit,
    viewModel: CreateVideoViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(prefillTopic) {
        if (!prefillTopic.isNullOrBlank()) viewModel.updateTopic(prefillTopic)
    }

    LaunchedEffect(Unit) { viewModel.refreshApiKeyStatus() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("New Video", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(4.dp))
        Text(
            "Script, voiceover, and scene images — free, powered by your own Gemini key + on-device text-to-speech.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
        )
        Spacer(Modifier.height(16.dp))

        if (!state.hasApiKey) {
            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.padding(16.dp)) {
                    Text("Add your free Gemini API key to generate scripts.", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = onOpenApiKeySettings) { Text("Add API Key") }
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        OutlinedTextField(
            value = state.topic,
            onValueChange = viewModel::updateTopic,
            label = { Text("What's your video about?") },
            placeholder = { Text("e.g. 5 mysterious deep-sea creatures") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        Spacer(Modifier.height(12.dp))

        val isBusy = state.step is CreateStep.GeneratingScript || state.step is CreateStep.GeneratingVoiceover
        Button(
            onClick = viewModel::generate,
            enabled = state.topic.isNotBlank() && !isBusy,
            modifier = Modifier.fillMaxWidth()
        ) {
            if (isBusy) {
                CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text(
                    when (state.step) {
                        is CreateStep.GeneratingScript -> "Writing script..."
                        is CreateStep.GeneratingVoiceover -> "Recording voiceover..."
                        else -> "Working..."
                    }
                )
            } else {
                Icon(Icons.Filled.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(6.dp))
                Text("Generate")
            }
        }

        val step = state.step
        if (step is CreateStep.Error) {
            Spacer(Modifier.height(12.dp))
            Text(step.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
        }

        if (state.step is CreateStep.Ready) {
            Spacer(Modifier.height(8.dp))
            Text("✓ Voiceover ready (${state.voiceoverFile?.name})", color = SuccessGreen, style = MaterialTheme.typography.bodyMedium)
        }

        if (state.scenes.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text("Scenes", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(state.scenes) { scene ->
                    Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(
                                model = scene.imageUrl,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(72.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Text(scene.text, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))

            val exportStep = state.exportStep
            val exporting = exportStep is ExportStep.DownloadingImages || exportStep is ExportStep.Rendering

            Button(
                onClick = viewModel::exportVideo,
                enabled = state.step is CreateStep.Ready && !exporting,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (exporting) {
                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(
                        when (exportStep) {
                            is ExportStep.DownloadingImages -> "Downloading images..."
                            is ExportStep.Rendering -> "Rendering video... ${exportStep.percent}%"
                            else -> "Working..."
                        }
                    )
                } else {
                    Icon(Icons.Filled.MovieCreation, contentDescription = null)
                    Spacer(Modifier.width(6.dp))
                    Text("Export Video")
                }
            }

            if (exportStep is ExportStep.Rendering) {
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { exportStep.percent / 100f },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (exportStep is ExportStep.Error) {
                Spacer(Modifier.height(8.dp))
                Text(exportStep.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            }

            if (exportStep is ExportStep.Done) {
                Spacer(Modifier.height(12.dp))
                Text("✓ Video ready (${exportStep.file.name})", color = SuccessGreen, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = {
                            val saved = VideoOutputUtils.saveToGallery(context, exportStep.file)
                            Toast.makeText(
                                context,
                                if (saved) "Saved to Movies/FacelessStudio" else "Could not save to gallery",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Save, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Save")
                    }
                    Button(
                        onClick = { context.startActivity(VideoOutputUtils.shareIntent(context, exportStep.file)) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Filled.Share, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Share")
                    }
                }

                Spacer(Modifier.height(12.dp))
                val publishStep = state.publishStep
                if (state.youtubeConnected) {
                    Button(
                        onClick = viewModel::publishToYouTube,
                        enabled = publishStep !is PublishStep.Uploading,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (publishStep is PublishStep.Uploading) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Uploading to YouTube...")
                        } else {
                            Text("Publish to YouTube (private)")
                        }
                    }
                    if (publishStep is PublishStep.Done) {
                        Spacer(Modifier.height(8.dp))
                        Text("✓ Uploaded: ${publishStep.videoUrl}", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                    }
                    if (publishStep is PublishStep.Error) {
                        Spacer(Modifier.height(8.dp))
                        Text(publishStep.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                } else {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Connect YouTube in Settings → Connected Accounts to publish directly.",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonBlue
                    )
                }

                Spacer(Modifier.height(12.dp))
                val tiktokPublishStep = state.tiktokPublishStep
                if (state.tiktokConnected) {
                    Button(
                        onClick = viewModel::publishToTikTok,
                        enabled = tiktokPublishStep !is PublishStep.Uploading,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (tiktokPublishStep is PublishStep.Uploading) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Uploading to TikTok...")
                        } else {
                            Text("Publish to TikTok (private)")
                        }
                    }
                    if (tiktokPublishStep is PublishStep.Done) {
                        Spacer(Modifier.height(8.dp))
                        Text("✓ ${tiktokPublishStep.videoUrl}", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                    }
                    if (tiktokPublishStep is PublishStep.Error) {
                        Spacer(Modifier.height(8.dp))
                        Text(tiktokPublishStep.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                } else {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Connect TikTok in Settings → Connected Accounts to publish directly.",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonBlue
                    )
                }

                Spacer(Modifier.height(12.dp))
                val facebookPublishStep = state.facebookPublishStep
                if (state.facebookConnected) {
                    Button(
                        onClick = viewModel::publishToFacebook,
                        enabled = facebookPublishStep !is PublishStep.Uploading,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (facebookPublishStep is PublishStep.Uploading) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Uploading to Facebook...")
                        } else {
                            Text("Publish to Facebook Page")
                        }
                    }
                    if (facebookPublishStep is PublishStep.Done) {
                        Spacer(Modifier.height(8.dp))
                        Text("✓ ${facebookPublishStep.videoUrl}", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                    }
                    if (facebookPublishStep is PublishStep.Error) {
                        Spacer(Modifier.height(8.dp))
                        Text(facebookPublishStep.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                } else {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Connect Facebook in Settings → Connected Accounts to publish directly.",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonBlue
                    )
                }

                Spacer(Modifier.height(12.dp))
                val pinterestPublishStep = state.pinterestPublishStep
                if (state.pinterestConnected) {
                    Button(
                        onClick = viewModel::publishToPinterest,
                        enabled = pinterestPublishStep !is PublishStep.Uploading,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        if (pinterestPublishStep is PublishStep.Uploading) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Uploading to Pinterest...")
                        } else {
                            Text("Publish to Pinterest")
                        }
                    }
                    if (pinterestPublishStep is PublishStep.Done) {
                        Spacer(Modifier.height(8.dp))
                        Text("✓ ${pinterestPublishStep.videoUrl}", color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                    }
                    if (pinterestPublishStep is PublishStep.Error) {
                        Spacer(Modifier.height(8.dp))
                        Text(pinterestPublishStep.message, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                    }
                } else {
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Connect Pinterest in Settings → Connected Accounts to publish directly.",
                        style = MaterialTheme.typography.labelSmall,
                        color = NeonBlue
                    )
                }

                if (state.youtubeConnected || state.tiktokConnected || state.facebookConnected || state.pinterestConnected) {
                    Spacer(Modifier.height(12.dp))
                    OutlinedButton(onClick = viewModel::openScheduleDialog, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.Schedule, contentDescription = null)
                        Spacer(Modifier.width(6.dp))
                        Text("Schedule for later")
                    }
                }
                state.scheduleConfirmation?.let { message ->
                    Spacer(Modifier.height(8.dp))
                    Text(message, color = SuccessGreen, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        if (state.showScheduleDialog) {
            ScheduleDialog(
                youtubeAvailable = state.youtubeConnected,
                tiktokAvailable = state.tiktokConnected,
                facebookAvailable = state.facebookConnected,
                pinterestAvailable = state.pinterestConnected,
                onDismiss = viewModel::dismissScheduleDialog,
                onConfirm = { platform, epochMillis -> viewModel.schedulePost(platform, epochMillis) }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ScheduleDialog(
    youtubeAvailable: Boolean,
    tiktokAvailable: Boolean,
    facebookAvailable: Boolean,
    pinterestAvailable: Boolean,
    onDismiss: () -> Unit,
    onConfirm: (com.facelessstudio.ai.domain.model.SocialPlatform, Long) -> Unit
) {
    var platform by remember {
        mutableStateOf(
            when {
                youtubeAvailable -> com.facelessstudio.ai.domain.model.SocialPlatform.YOUTUBE
                tiktokAvailable -> com.facelessstudio.ai.domain.model.SocialPlatform.TIKTOK
                facebookAvailable -> com.facelessstudio.ai.domain.model.SocialPlatform.FACEBOOK
                else -> com.facelessstudio.ai.domain.model.SocialPlatform.PINTEREST
            }
        )
    }
    val datePickerState = rememberDatePickerState(initialSelectedDateMillis = System.currentTimeMillis())
    val timePickerState = rememberTimePickerState(is24Hour = false)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Schedule Post") },
        text = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (youtubeAvailable) {
                        FilterChip(
                            selected = platform == com.facelessstudio.ai.domain.model.SocialPlatform.YOUTUBE,
                            onClick = { platform = com.facelessstudio.ai.domain.model.SocialPlatform.YOUTUBE },
                            label = { Text("YouTube") }
                        )
                        Spacer(Modifier.width(8.dp))
                    }
                    if (tiktokAvailable) {
                        FilterChip(
                            selected = platform == com.facelessstudio.ai.domain.model.SocialPlatform.TIKTOK,
                            onClick = { platform = com.facelessstudio.ai.domain.model.SocialPlatform.TIKTOK },
                            label = { Text("TikTok") }
                        )
                        Spacer(Modifier.width(8.dp))
                    }
                    if (facebookAvailable) {
                        FilterChip(
                            selected = platform == com.facelessstudio.ai.domain.model.SocialPlatform.FACEBOOK,
                            onClick = { platform = com.facelessstudio.ai.domain.model.SocialPlatform.FACEBOOK },
                            label = { Text("Facebook") }
                        )
                        Spacer(Modifier.width(8.dp))
                    }
                    if (pinterestAvailable) {
                        FilterChip(
                            selected = platform == com.facelessstudio.ai.domain.model.SocialPlatform.PINTEREST,
                            onClick = { platform = com.facelessstudio.ai.domain.model.SocialPlatform.PINTEREST },
                            label = { Text("Pinterest") }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                DatePicker(state = datePickerState, showModeToggle = false)
                Spacer(Modifier.height(8.dp))
                TimePicker(state = timePickerState)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val calendar = java.util.Calendar.getInstance().apply {
                    timeInMillis = datePickerState.selectedDateMillis ?: System.currentTimeMillis()
                    set(java.util.Calendar.HOUR_OF_DAY, timePickerState.hour)
                    set(java.util.Calendar.MINUTE, timePickerState.minute)
                    set(java.util.Calendar.SECOND, 0)
                }
                onConfirm(platform, calendar.timeInMillis)
            }) {
                Text("Schedule")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
