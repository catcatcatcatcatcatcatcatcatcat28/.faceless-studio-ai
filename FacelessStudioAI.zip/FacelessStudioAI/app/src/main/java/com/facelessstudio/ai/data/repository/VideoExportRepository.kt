package com.facelessstudio.ai.data.repository

import android.content.Context
import android.media.MediaMetadataRetriever
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** One scene: its narration text (unused for rendering, kept for reference) and an image to show while it plays. */
data class ExportScene(val text: String, val imageUrl: String)

/**
 * Combines generated scene images + the TTS voiceover file into a single exportable MP4,
 * using AndroidX Media3 Transformer (no FFmpeg / native deps needed).
 *
 * Pipeline:
 *  1. Download each scene image to a local cache file (Transformer needs local URIs).
 *  2. Read the voiceover's duration and split it evenly across the scenes, so total
 *     image time lines up with the narration length.
 *  3. Build an image sequence (visual track) + an audio sequence (voiceover track) and
 *     run them through Transformer as one Composition.
 */
@Singleton
class VideoExportRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val okHttpClient: OkHttpClient
) {
    sealed class ExportProgress {
        data object Downloading : ExportProgress()
        data class Rendering(val percent: Int) : ExportProgress()
    }

    suspend fun exportVideo(
        scenes: List<ExportScene>,
        voiceoverFile: File,
        onProgress: (ExportProgress) -> Unit
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            require(scenes.isNotEmpty()) { "No scenes to export." }

            onProgress(ExportProgress.Downloading)
            val imageFiles = scenes.mapIndexed { index, scene ->
                downloadImage(scene.imageUrl, index)
            }

            val totalDurationUs = audioDurationUs(voiceoverFile)
            val perSceneDurationUs = (totalDurationUs / scenes.size).coerceAtLeast(500_000L) // min 0.5s/scene

            val imageItems = imageFiles.map { file ->
                val mediaItem = MediaItem.Builder()
                    .setUri(file.toURI().toString())
                    .setMimeType(MimeTypes.IMAGE_JPEG)
                    .build()
                EditedMediaItem.Builder(mediaItem)
                    .setDurationUs(perSceneDurationUs)
                    .setFrameRate(30)
                    .build()
            }
            val imageSequence = EditedMediaItemSequence(imageItems)

            val audioItem = EditedMediaItem.Builder(
                MediaItem.fromUri(voiceoverFile.toURI().toString())
            ).build()
            val audioSequence = EditedMediaItemSequence(listOf(audioItem))

            val composition = Composition.Builder(imageSequence, audioSequence).build()

            val outputFile = File(context.cacheDir, "faceless_export_${UUID.randomUUID()}.mp4")
            runTransformer(composition, outputFile, onProgress)

            Result.success(outputFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun downloadImage(url: String, index: Int): File {
        val request = Request.Builder().url(url).build()
        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                throw IllegalStateException("Failed to download scene image ${index + 1} (HTTP ${response.code}).")
            }
            val bytes = response.body?.bytes()
                ?: throw IllegalStateException("Empty image response for scene ${index + 1}.")
            val file = File(context.cacheDir, "scene_${UUID.randomUUID()}.jpg")
            file.writeBytes(bytes)
            return file
        }
    }

    private fun audioDurationUs(file: File): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            val ms = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            ms * 1000L
        } finally {
            retriever.release()
        }
    }

    /**
     * Transformer must be created + driven on a thread with a Looper (main thread is simplest).
     * We bridge its callback-based listener into a suspend function, and poll getProgress()
     * on a Handler loop so the UI can show a real percentage.
     */
    private suspend fun runTransformer(
        composition: Composition,
        outputFile: File,
        onProgress: (ExportProgress) -> Unit
    ) = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<Unit> { cont ->
            val transformer = Transformer.Builder(context)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (cont.isActive) cont.resume(Unit)
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException
                    ) {
                        if (cont.isActive) cont.resumeWithException(exportException)
                    }
                })
                .build()

            val progressHolder = ProgressHolder()
            val handler = Handler(Looper.getMainLooper())
            val poll = object : Runnable {
                override fun run() {
                    val state = transformer.getProgress(progressHolder)
                    if (state != Transformer.PROGRESS_STATE_NOT_STARTED) {
                        onProgress(ExportProgress.Rendering(progressHolder.progress))
                    }
                    if (state != Transformer.PROGRESS_STATE_NOT_STARTED && cont.isActive) {
                        handler.postDelayed(this, 300)
                    }
                }
            }

            cont.invokeOnCancellation {
                handler.removeCallbacksAndMessages(null)
                transformer.cancel()
            }

            transformer.start(composition, outputFile.absolutePath)
            handler.postDelayed(poll, 300)
        }
    }
}
