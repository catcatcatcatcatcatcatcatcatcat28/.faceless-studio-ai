package com.facelessstudio.ai.ui.screens.schedule

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.facelessstudio.ai.data.local.ScheduleStatus
import com.facelessstudio.ai.data.local.ScheduledPostEntity
import com.facelessstudio.ai.ui.theme.DangerRed
import com.facelessstudio.ai.ui.theme.MutedGray
import com.facelessstudio.ai.ui.theme.NeonBlue
import com.facelessstudio.ai.ui.theme.SuccessGreen
import java.text.DateFormat
import java.util.Date

@Composable
fun ScheduledPostsScreen(
    onBack: () -> Unit,
    viewModel: ScheduledPostsViewModel = hiltViewModel()
) {
    val posts by viewModel.scheduledPosts.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text("Scheduled Posts", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        if (posts.isEmpty()) {
            Text(
                "No scheduled posts yet. After exporting a video, use \"Schedule\" instead of \"Publish\" to queue it for later.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(posts, key = { it.id }) { post ->
                    ScheduledPostRow(post = post, onCancel = { viewModel.cancel(post.id) })
                }
            }
        }
    }
}

@Composable
private fun ScheduledPostRow(post: ScheduledPostEntity, onCancel: () -> Unit) {
    Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(post.title.ifBlank { "(untitled)" }, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                StatusChip(post.status)
            }
            Spacer(Modifier.height(4.dp))
            Text(
                "${post.platform} · ${DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(post.scheduledAtEpochMillis))}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            post.errorMessage?.let {
                Spacer(Modifier.height(4.dp))
                Text(it, style = MaterialTheme.typography.bodySmall, color = DangerRed)
            }
            post.resultUrlOrId?.let {
                Spacer(Modifier.height(4.dp))
                Text(it, style = MaterialTheme.typography.bodySmall, color = SuccessGreen)
            }
            if (post.status == ScheduleStatus.PENDING.name) {
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = onCancel) { Text("Cancel") }
            }
        }
    }
}

@Composable
private fun StatusChip(status: String) {
    val color = when (status) {
        ScheduleStatus.PUBLISHED.name -> SuccessGreen
        ScheduleStatus.FAILED.name -> DangerRed
        ScheduleStatus.CANCELLED.name -> MutedGray
        ScheduleStatus.PUBLISHING.name -> NeonBlue
        else -> NeonBlue
    }
    AssistChip(
        onClick = {},
        label = { Text(status.lowercase().replaceFirstChar { it.uppercase() }) },
        colors = AssistChipDefaults.assistChipColors(labelColor = color)
    )
}
