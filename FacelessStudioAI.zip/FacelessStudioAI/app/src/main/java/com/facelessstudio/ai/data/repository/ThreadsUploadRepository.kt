package com.facelessstudio.ai.data.repository

import com.facelessstudio.ai.domain.model.SocialPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Publishes to Threads via Meta's Threads API (container -> poll -> publish),
 * the same pattern as Instagram.
 *
 * IMPORTANT LIMITATION (same root cause as Instagram — it's the same Meta
 * publishing infrastructure under the hood): the /threads container endpoint
 * only accepts a `video_url` it can fetch over the public internet. There is
 * no direct-file-upload path from a device in the official API, so this can't
 * be a one-tap button the way YouTube/TikTok/Facebook/Pinterest are. Export
 * your video, host it somewhere public, then paste that URL in Threads'
 * "Publish (Advanced)" settings screen.
 */
@Singleton
class ThreadsUploadRepository @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val oauthRepository: OAuthRepository,
    private val credentialsRepository: OAuthCredentialsRepository
) {
    suspend fun upload(videoUrl: String, text: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val token = oauthRepository.validAccessToken(SocialPlatform.THREADS)
                ?: return@withContext Result.failure(IllegalStateException("Not connected to Threads."))
            val threadsUserId = resolveThreadsUserId(token)
                ?: return@withContext Result.failure(IllegalStateException("Could not resolve your Threads user ID."))

            // Step 1: create the media container.
            val createForm = FormBody.Builder()
                .add("media_type", "VIDEO")
                .add("video_url", videoUrl)
                .add("text", text)
                .add("access_token", token)
                .build()
            val createRequest = Request.Builder()
                .url("https://graph.threads.net/v1.0/$threadsUserId/threads")
                .post(createForm)
                .build()

            val containerId = okHttpClient.newCall(createRequest).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Threads container creation failed (HTTP ${response.code}): $body"))
                }
                JSONObject(body).optString("id").ifBlank {
                    return@withContext Result.failure(IllegalStateException("Threads didn't return a container ID."))
                }
            }

            // Step 2: poll until Threads finishes fetching + processing the video.
            var ready = false
            repeat(20) {
                delay(3000)
                val statusUrl = "https://graph.threads.net/v1.0/$containerId?fields=status&access_token=$token"
                okHttpClient.newCall(Request.Builder().url(statusUrl).build()).execute().use { response ->
                    if (response.isSuccessful) {
                        val status = JSONObject(response.body?.string().orEmpty()).optString("status")
                        when (status) {
                            "FINISHED" -> ready = true
                            "ERROR" -> return@withContext Result.failure(IllegalStateException("Threads failed to process the video."))
                        }
                    }
                }
            }
            if (!ready) return@withContext Result.failure(IllegalStateException("Threads is still processing — try publishing again shortly."))

            // Step 3: publish the container.
            val publishForm = FormBody.Builder()
                .add("creation_id", containerId)
                .add("access_token", token)
                .build()
            val publishRequest = Request.Builder()
                .url("https://graph.threads.net/v1.0/$threadsUserId/threads_publish")
                .post(publishForm)
                .build()

            okHttpClient.newCall(publishRequest).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Threads publish failed (HTTP ${response.code}): $body"))
                }
                val postId = JSONObject(body).optString("id")
                if (postId.isBlank()) {
                    Result.failure(IllegalStateException("Publish succeeded but Threads returned no post ID."))
                } else {
                    Result.success("Threads post id: $postId")
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Threads' publishing endpoints are scoped under /{threads-user-id}/..., which
     * isn't returned by the OAuth token exchange itself — it has to be looked up once
     * via /me and then cached, same "extra" pattern MetaPageRepository uses for Facebook. */
    private suspend fun resolveThreadsUserId(token: String): String? {
        credentialsRepository.extra(SocialPlatform.THREADS, "user_id")?.let { return it }

        val request = Request.Builder()
            .url("https://graph.threads.net/v1.0/me?fields=id&access_token=$token")
            .build()
        return okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return null
            val id = JSONObject(response.body?.string().orEmpty()).optString("id").ifBlank { null }
            id?.also { credentialsRepository.saveExtra(SocialPlatform.THREADS, "user_id", it) }
        }
    }
}
