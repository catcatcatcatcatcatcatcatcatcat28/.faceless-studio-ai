package com.facelessstudio.ai.domain.model

enum class TrendSource(val displayName: String) {
    GOOGLE_TRENDS("Google Trends"),
    REDDIT("Reddit r/all")
}

data class TrendTopic(
    val title: String,
    val source: TrendSource,
    val approxTraffic: String? = null, // e.g. "200K+ searches" (Google Trends) or "45.2k upvotes" (Reddit)
    val context: String? = null,       // short related-article headline or subreddit, if available
    val url: String? = null
)
