package com.facelessstudio.ai.data.remote

import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Query

/**
 * Google Gemini API — free tier (as of writing, gemini-1.5-flash has a generous
 * free daily quota with no credit card required). Get a free key at:
 * https://aistudio.google.com/app/apikey
 *
 * Base URL: https://generativelanguage.googleapis.com/
 */
interface GeminiApi {
    @POST("v1beta/models/gemini-1.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GeminiRequest
    ): GeminiResponse
}

data class GeminiRequest(
    val contents: List<GeminiContent>
)

data class GeminiContent(
    val parts: List<GeminiPart>
)

data class GeminiPart(
    val text: String
)

data class GeminiResponse(
    val candidates: List<GeminiCandidate>?
)

data class GeminiCandidate(
    val content: GeminiContent?
)

/** Convenience extractor for the plain text of the first candidate. */
fun GeminiResponse.firstText(): String? =
    candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
