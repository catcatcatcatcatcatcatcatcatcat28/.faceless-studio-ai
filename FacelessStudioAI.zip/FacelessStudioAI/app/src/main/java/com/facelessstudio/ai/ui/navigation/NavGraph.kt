package com.facelessstudio.ai.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.facelessstudio.ai.domain.model.SocialPlatform
import com.facelessstudio.ai.ui.screens.create.CreateVideoScreen
import com.facelessstudio.ai.ui.screens.home.HomeScreen
import com.facelessstudio.ai.ui.screens.settings.ApiKeySettingsScreen
import com.facelessstudio.ai.ui.screens.settings.SettingsScreen
import com.facelessstudio.ai.ui.screens.schedule.ScheduledPostsScreen
import com.facelessstudio.ai.ui.screens.social.PlatformSettingsScreen
import com.facelessstudio.ai.ui.screens.social.SocialConnectionsScreen
import com.facelessstudio.ai.ui.screens.trends.TrendDiscoveryScreen
import java.net.URLDecoder
import java.net.URLEncoder

object Routes {
    const val HOME = "home"
    const val CREATE_VIDEO = "create?topic={topic}"
    const val SETTINGS = "settings"
    const val API_KEY_SETTINGS = "settings/api-keys"
    const val SOCIAL_CONNECTIONS = "settings/social"
    const val PLATFORM_SETTINGS = "settings/social/{platform}"
    const val TRENDS = "trends"
    const val SCHEDULED_POSTS = "settings/scheduled-posts"
    fun platformSettings(platform: SocialPlatform) = "settings/social/${platform.name}"
    fun createVideo(topic: String? = null): String {
        val encoded = topic?.let { URLEncoder.encode(it, "UTF-8") }.orEmpty()
        return "create?topic=$encoded"
    }
}

@Composable
fun FacelessStudioNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.HOME) {

        composable(Routes.HOME) {
            HomeScreen(
                onNewVideo = { navController.navigate(Routes.createVideo()) },
                onDiscoverTrends = { navController.navigate(Routes.TRENDS) }
            )
        }

        composable(
            route = Routes.CREATE_VIDEO,
            arguments = listOf(navArgument("topic") { type = NavType.StringType; defaultValue = "" })
        ) { backStackEntry ->
            val encodedTopic = backStackEntry.arguments?.getString("topic").orEmpty()
            val prefillTopic = if (encodedTopic.isBlank()) null else URLDecoder.decode(encodedTopic, "UTF-8")
            CreateVideoScreen(
                prefillTopic = prefillTopic,
                onOpenApiKeySettings = { navController.navigate(Routes.API_KEY_SETTINGS) }
            )
        }

        composable(Routes.TRENDS) {
            TrendDiscoveryScreen(
                onUseTrendAsTopic = { topic ->
                    navController.navigate(Routes.createVideo(topic)) {
                        popUpTo(Routes.HOME)
                    }
                },
                onBack = { navController.popBackStack() }
            )
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                onOpenSocialConnections = { navController.navigate(Routes.SOCIAL_CONNECTIONS) },
                onOpenApiKeySettings = { navController.navigate(Routes.API_KEY_SETTINGS) },
                onOpenScheduledPosts = { navController.navigate(Routes.SCHEDULED_POSTS) }
            )
        }

        composable(Routes.SCHEDULED_POSTS) {
            ScheduledPostsScreen(onBack = { navController.popBackStack() })
        }

        composable(Routes.API_KEY_SETTINGS) {
            ApiKeySettingsScreen(onBack = { navController.popBackStack() })
        }

        composable(Routes.SOCIAL_CONNECTIONS) {
            SocialConnectionsScreen(
                onOpenPlatformSettings = { platform ->
                    navController.navigate(Routes.platformSettings(platform))
                }
            )
        }

        composable(
            route = Routes.PLATFORM_SETTINGS,
            arguments = listOf(navArgument("platform") { type = NavType.StringType })
        ) { backStackEntry ->
            val platformArg = backStackEntry.arguments?.getString("platform")
            val platform = SocialPlatform.entries.firstOrNull { it.name == platformArg }
                ?: SocialPlatform.YOUTUBE
            PlatformSettingsScreen(
                platform = platform,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
