package com.facelessstudio.ai.ui.screens.social

import android.app.Activity
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.facelessstudio.ai.data.repository.InstagramUploadRepository
import com.facelessstudio.ai.data.repository.ManagedPage
import com.facelessstudio.ai.data.repository.MetaPageRepository
import com.facelessstudio.ai.data.repository.OAuthCredentialsRepository
import com.facelessstudio.ai.data.repository.OAuthRepository
import com.facelessstudio.ai.data.repository.PinterestBoard
import com.facelessstudio.ai.data.repository.PinterestBoardRepository
import com.facelessstudio.ai.data.repository.SocialAccountRepository
import com.facelessstudio.ai.data.repository.ThreadsUploadRepository
import com.facelessstudio.ai.domain.model.SocialPlatform
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SocialConnectionsViewModel @Inject constructor(
    private val repository: SocialAccountRepository,
    private val oauthRepository: OAuthRepository,
    private val credentialsRepository: OAuthCredentialsRepository,
    private val metaPageRepository: MetaPageRepository,
    private val instagramUploadRepository: InstagramUploadRepository,
    private val pinterestBoardRepository: PinterestBoardRepository,
    private val threadsUploadRepository: ThreadsUploadRepository
) : ViewModel() {

    val accounts: StateFlow<Map<SocialPlatform, com.facelessstudio.ai.domain.model.SocialAccount>> =
        repository.accounts

    private val _connectError = MutableStateFlow<String?>(null)
    val connectError: StateFlow<String?> = _connectError

    private val _isConnecting = MutableStateFlow(false)
    val isConnecting: StateFlow<Boolean> = _isConnecting

    private val _managedPages = MutableStateFlow<List<ManagedPage>>(emptyList())
    val managedPages: StateFlow<List<ManagedPage>> = _managedPages

    private val _pagesError = MutableStateFlow<String?>(null)
    val pagesError: StateFlow<String?> = _pagesError

    private val _isLoadingPages = MutableStateFlow(false)
    val isLoadingPages: StateFlow<Boolean> = _isLoadingPages

    private val _instagramPublishResult = MutableStateFlow<String?>(null)
    val instagramPublishResult: StateFlow<String?> = _instagramPublishResult

    private val _instagramPublishing = MutableStateFlow(false)
    val instagramPublishing: StateFlow<Boolean> = _instagramPublishing

    fun clientId(platform: SocialPlatform): String = credentialsRepository.clientId(platform)
    fun clientSecret(platform: SocialPlatform): String = credentialsRepository.clientSecret(platform)

    fun saveClientCredentials(platform: SocialPlatform, clientId: String, clientSecret: String) {
        credentialsRepository.saveClientCredentials(platform, clientId, clientSecret)
    }

    /** Launches the real OAuth consent screen for [platform] via Custom Tabs. */
    fun connect(activity: Activity, platform: SocialPlatform) = viewModelScope.launch {
        _connectError.value = null
        _isConnecting.value = true
        val result = oauthRepository.beginAuth(activity, platform)
        _isConnecting.value = false
        result.onFailure { e -> _connectError.value = e.message ?: "Could not connect ${platform.displayName}." }
    }

    fun dismissError() {
        _connectError.value = null
    }

    fun disconnect(platform: SocialPlatform) = viewModelScope.launch {
        oauthRepository.disconnect(platform)
    }

    fun setAutoPublish(platform: SocialPlatform, enabled: Boolean) = viewModelScope.launch {
        repository.updatePreferences(platform, autoPublishEnabled = enabled)
    }

    fun setVisibility(platform: SocialPlatform, visibility: String) = viewModelScope.launch {
        repository.updatePreferences(platform, defaultVisibility = visibility)
    }

    fun setWatermark(platform: SocialPlatform, enabled: Boolean) = viewModelScope.launch {
        repository.updatePreferences(platform, includeWatermark = enabled)
    }

    // --- Facebook Page selection (also determines the linked Instagram Business Account) ---

    fun selectedPageName(): String? = metaPageRepository.selectedPageName()
    fun linkedInstagramName(): String? = metaPageRepository.linkedInstagramBusinessId()

    fun loadManagedPages() = viewModelScope.launch {
        _isLoadingPages.value = true
        _pagesError.value = null
        val result = metaPageRepository.fetchManagedPages()
        _isLoadingPages.value = false
        result.fold(
            onSuccess = { _managedPages.value = it },
            onFailure = { e -> _pagesError.value = e.message ?: "Could not load Facebook Pages." }
        )
    }

    fun choosePage(page: ManagedPage) {
        metaPageRepository.selectPage(page)
        _managedPages.value = emptyList()
    }

    // --- Instagram advanced manual publish (requires a publicly-hosted video URL — see InstagramUploadRepository) ---

    fun publishToInstagram(videoUrl: String, caption: String) = viewModelScope.launch {
        _instagramPublishing.value = true
        _instagramPublishResult.value = null
        val result = instagramUploadRepository.upload(videoUrl, caption)
        _instagramPublishing.value = false
        _instagramPublishResult.value = result.fold(
            onSuccess = { "✓ $it" },
            onFailure = { e -> "✗ ${e.message}" }
        )
    }

    // --- Pinterest board selection (real device upload, no public hosting needed) ---

    private val _pinterestBoards = MutableStateFlow<List<PinterestBoard>>(emptyList())
    val pinterestBoards: StateFlow<List<PinterestBoard>> = _pinterestBoards

    private val _isLoadingBoards = MutableStateFlow(false)
    val isLoadingBoards: StateFlow<Boolean> = _isLoadingBoards

    private val _boardsError = MutableStateFlow<String?>(null)
    val boardsError: StateFlow<String?> = _boardsError

    fun selectedBoardName(): String? = pinterestBoardRepository.selectedBoardName()

    fun loadPinterestBoards() = viewModelScope.launch {
        _isLoadingBoards.value = true
        _boardsError.value = null
        val result = pinterestBoardRepository.fetchBoards()
        _isLoadingBoards.value = false
        result.fold(
            onSuccess = { _pinterestBoards.value = it },
            onFailure = { e -> _boardsError.value = e.message ?: "Could not load Pinterest boards." }
        )
    }

    fun chooseBoard(board: PinterestBoard) {
        pinterestBoardRepository.selectBoard(board)
        _pinterestBoards.value = emptyList()
    }

    // --- Threads advanced manual publish (requires a publicly-hosted video URL — see ThreadsUploadRepository) ---

    private val _threadsPublishResult = MutableStateFlow<String?>(null)
    val threadsPublishResult: StateFlow<String?> = _threadsPublishResult

    private val _threadsPublishing = MutableStateFlow(false)
    val threadsPublishing: StateFlow<Boolean> = _threadsPublishing

    fun publishToThreads(videoUrl: String, text: String) = viewModelScope.launch {
        _threadsPublishing.value = true
        _threadsPublishResult.value = null
        val result = threadsUploadRepository.upload(videoUrl, text)
        _threadsPublishing.value = false
        _threadsPublishResult.value = result.fold(
            onSuccess = { "✓ $it" },
            onFailure = { e -> "✗ ${e.message}" }
        )
    }
}
