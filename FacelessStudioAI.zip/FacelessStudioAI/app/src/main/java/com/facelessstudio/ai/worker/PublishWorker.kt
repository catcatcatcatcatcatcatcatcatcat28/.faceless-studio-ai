package com.facelessstudio.ai.worker

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.facelessstudio.ai.data.local.ScheduleStatus
import com.facelessstudio.ai.data.local.ScheduledPostDao
import com.facelessstudio.ai.data.repository.FacebookUploadRepository
import com.facelessstudio.ai.data.repository.PinterestUploadRepository
import com.facelessstudio.ai.data.repository.TikTokUploadRepository
import com.facelessstudio.ai.data.repository.YouTubeUploadRepository
import com.facelessstudio.ai.domain.model.SocialPlatform
import com.facelessstudio.ai.notifications.NotificationHelper
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import java.io.File

/**
 * Fires at (or shortly after) the scheduled time and actually publishes the
 * exported video, using the same upload repositories the manual "Publish"
 * buttons use. Only platforms with a real local-file upload (YouTube, TikTok,
 * Facebook, Pinterest) can be scheduled — Instagram and Threads require a
 * publicly-hosted video URL and aren't wired to the one-tap flow (see their
 * upload repositories).
 */
@HiltWorker
class PublishWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val dao: ScheduledPostDao,
    private val youTubeUploadRepository: YouTubeUploadRepository,
    private val tikTokUploadRepository: TikTokUploadRepository,
    private val facebookUploadRepository: FacebookUploadRepository,
    private val pinterestUploadRepository: PinterestUploadRepository,
    private val notificationHelper: NotificationHelper
) : CoroutineWorker(context, params) {

    companion object {
        const val KEY_POST_ID = "post_id"
    }

    override suspend fun doWork(): Result {
        val postId = inputData.getString(KEY_POST_ID) ?: return Result.failure()
        val post = dao.getById(postId) ?: return Result.failure()

        val videoFile = File(post.videoFilePath)
        if (!videoFile.exists()) {
            val message = "Exported video file was deleted before its scheduled time."
            dao.updateResult(postId, ScheduleStatus.FAILED.name, null, message)
            notificationHelper.notifyPublishResult(post.platform, success = false, detail = message)
            return Result.failure()
        }

        dao.updateStatus(postId, ScheduleStatus.PUBLISHING.name)

        val platform = SocialPlatform.entries.firstOrNull { it.name == post.platform }
        val uploadResult = when (platform) {
            SocialPlatform.YOUTUBE -> youTubeUploadRepository.upload(videoFile, post.title, post.description)
            SocialPlatform.TIKTOK -> tikTokUploadRepository.upload(videoFile, post.title)
            SocialPlatform.FACEBOOK -> facebookUploadRepository.upload(videoFile, post.title, post.description)
            SocialPlatform.PINTEREST -> pinterestUploadRepository.upload(videoFile, post.title, post.description)
            else -> Result.failure(IllegalStateException("Scheduled publishing isn't supported for ${post.platform} yet."))
        }

        return uploadResult.fold(
            onSuccess = { resultRef ->
                dao.updateResult(postId, ScheduleStatus.PUBLISHED.name, resultRef, null)
                notificationHelper.notifyPublishResult(post.platform, success = true, detail = "\"${post.title}\" is live. $resultRef")
                Result.success()
            },
            onFailure = { e ->
                val message = e.message ?: "Unknown error."
                dao.updateResult(postId, ScheduleStatus.FAILED.name, null, message)
                notificationHelper.notifyPublishResult(post.platform, success = false, detail = message)
                Result.failure()
            }
        )
    }
}
