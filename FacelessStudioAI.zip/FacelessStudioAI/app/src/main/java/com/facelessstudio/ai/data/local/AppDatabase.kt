package com.facelessstudio.ai.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [ScheduledPostEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun scheduledPostDao(): ScheduledPostDao
}
