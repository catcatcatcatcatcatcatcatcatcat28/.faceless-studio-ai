package com.facelessstudio.ai.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import com.facelessstudio.ai.R
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.concurrent.atomic.AtomicInteger
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Local notifications for render/upload/error events. Most useful for
 * scheduled posts, since PublishWorker can fire while the app is closed —
 * without a notification the user would have no idea it succeeded or failed
 * short of opening Settings → Scheduled Posts.
 */
@Singleton
class NotificationHelper @Inject constructor(
    @ApplicationContext private val context: Context
) {
    companion object {
        const val CHANNEL_ID = "faceless_studio_events"
        private val idGenerator = AtomicInteger(1000)
    }

    fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Render & Publish Updates",
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Alerts when a video finishes rendering or publishing, including scheduled posts."
            }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    fun notifyExportComplete() = notify(
        title = "Video ready",
        text = "Your export finished. Open the app to save, share, or publish it."
    )

    fun notifyExportFailed(reason: String) = notify(
        title = "Export failed",
        text = reason
    )

    fun notifyPublishResult(platformName: String, success: Boolean, detail: String) = notify(
        title = if (success) "Published to $platformName" else "Publish to $platformName failed",
        text = detail
    )

    private fun notify(title: String, text: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ActivityCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()

        androidx.core.app.NotificationManagerCompat.from(context)
            .notify(idGenerator.incrementAndGet(), notification)
    }
}
