package com.facelessstudio.ai.data.repository

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Stores the user's own free Gemini API key on-device, encrypted.
 * Get a free key (no credit card) at https://aistudio.google.com/app/apikey
 */
@Singleton
class ApiKeyRepository @Inject constructor(
    @ApplicationContext context: Context
) {
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "secure_api_keys",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    private val _geminiKey = MutableStateFlow(prefs.getString(KEY_GEMINI, "") ?: "")
    val geminiKey: StateFlow<String> = _geminiKey

    fun saveGeminiKey(key: String) {
        prefs.edit().putString(KEY_GEMINI, key).apply()
        _geminiKey.value = key
    }

    fun hasGeminiKey(): Boolean = _geminiKey.value.isNotBlank()

    companion object {
        private const val KEY_GEMINI = "gemini_api_key"
    }
}
