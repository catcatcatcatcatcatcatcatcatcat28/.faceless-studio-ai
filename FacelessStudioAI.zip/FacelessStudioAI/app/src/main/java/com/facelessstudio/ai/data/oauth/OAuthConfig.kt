package com.facelessstudio.ai.data.oauth

import com.facelessstudio.ai.domain.model.SocialPlatform

/**
 * OAuth 2.0 endpoints + scopes per platform. Each platform requires the app owner
 * (you) to register a developer app on that platform's console and get a Client ID
 * (and, for some, a Client Secret). Users enter those in the platform's settings
 * screen — same "bring your own credentials" pattern as the Gemini API key.
 *
 * Redirect URI for every platform is the deep link already declared in the manifest:
 * facelessstudio://oauth-callback
 */
data class OAuthConfig(
    val platform: SocialPlatform,
    val authEndpoint: String,
    val tokenEndpoint: String,
    val scope: String,
    val usesPkce: Boolean = true,
    val requiresClientSecret: Boolean = false,
    val extraAuthParams: Map<String, String> = emptyMap()
)

object OAuthConfigs {
    const val REDIRECT_URI = "facelessstudio://oauth-callback"

    val byPlatform: Map<SocialPlatform, OAuthConfig> = mapOf(
        SocialPlatform.YOUTUBE to OAuthConfig(
            platform = SocialPlatform.YOUTUBE,
            authEndpoint = "https://accounts.google.com/o/oauth2/v2/auth",
            tokenEndpoint = "https://oauth2.googleapis.com/token",
            scope = "https://www.googleapis.com/auth/youtube.upload https://www.googleapis.com/auth/userinfo.profile",
            usesPkce = true,
            requiresClientSecret = false,
            extraAuthParams = mapOf("access_type" to "offline", "prompt" to "consent")
        ),
        SocialPlatform.TIKTOK to OAuthConfig(
            platform = SocialPlatform.TIKTOK,
            authEndpoint = "https://www.tiktok.com/v2/auth/authorize/",
            tokenEndpoint = "https://open.tiktokapis.com/v2/oauth/token/",
            scope = "user.info.basic,video.publish,video.upload",
            usesPkce = true,
            requiresClientSecret = true // TikTok requires client_key + client_secret at token exchange
        ),
        SocialPlatform.FACEBOOK to OAuthConfig(
            platform = SocialPlatform.FACEBOOK,
            authEndpoint = "https://www.facebook.com/v19.0/dialog/oauth",
            tokenEndpoint = "https://graph.facebook.com/v19.0/oauth/access_token",
            scope = "pages_manage_posts,pages_read_engagement,publish_video",
            usesPkce = false,
            requiresClientSecret = true
        ),
        SocialPlatform.INSTAGRAM to OAuthConfig(
            platform = SocialPlatform.INSTAGRAM,
            authEndpoint = "https://www.facebook.com/v19.0/dialog/oauth", // Instagram Graph API auths through Meta
            tokenEndpoint = "https://graph.facebook.com/v19.0/oauth/access_token",
            scope = "instagram_basic,instagram_content_publish,pages_show_list",
            usesPkce = false,
            requiresClientSecret = true
        ),
        SocialPlatform.THREADS to OAuthConfig(
            platform = SocialPlatform.THREADS,
            authEndpoint = "https://threads.net/oauth/authorize",
            tokenEndpoint = "https://graph.threads.net/oauth/access_token",
            scope = "threads_basic,threads_content_publish",
            usesPkce = false,
            requiresClientSecret = true
        ),
        SocialPlatform.PINTEREST to OAuthConfig(
            platform = SocialPlatform.PINTEREST,
            authEndpoint = "https://www.pinterest.com/oauth/",
            tokenEndpoint = "https://api.pinterest.com/v5/oauth/token",
            scope = "boards:read,pins:read,pins:write",
            usesPkce = true,
            requiresClientSecret = true
        )
    )
}
