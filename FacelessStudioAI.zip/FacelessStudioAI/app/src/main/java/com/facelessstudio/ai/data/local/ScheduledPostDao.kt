package com.facelessstudio.ai.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ScheduledPostDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(post: ScheduledPostEntity)

    @Update
    suspend fun update(post: ScheduledPostEntity)

    @Query("SELECT * FROM scheduled_posts ORDER BY scheduledAtEpochMillis ASC")
    fun observeAll(): Flow<List<ScheduledPostEntity>>

    @Query("SELECT * FROM scheduled_posts WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): ScheduledPostEntity?

    @Query("UPDATE scheduled_posts SET status = :status WHERE id = :id")
    suspend fun updateStatus(id: String, status: String)

    @Query("UPDATE scheduled_posts SET status = :status, resultUrlOrId = :resultUrlOrId, errorMessage = :errorMessage WHERE id = :id")
    suspend fun updateResult(id: String, status: String, resultUrlOrId: String?, errorMessage: String?)
}
