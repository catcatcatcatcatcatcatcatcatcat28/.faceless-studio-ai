package com.facelessstudio.ai.data.repository

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.util.Locale
import java.util.UUID
import javax.inject.Inject
import javax.inject.Singleton
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Voiceover generator using Android's built-in Text-to-Speech engine.
 * 100% free, works fully offline, no API key, no internet required.
 * Quality is more "robotic" than paid AI voice services (like ElevenLabs),
 * but it costs nothing and needs zero setup.
 */
@Singleton
class VoiceoverRepository @Inject constructor(
    @ApplicationContext private val context: Context
) {
    private var tts: TextToSpeech? = null
    private var isReady = false

    private suspend fun ensureInitialized(): TextToSpeech = suspendCancellableCoroutine { cont ->
        if (isReady && tts != null) {
            cont.resume(tts!!)
            return@suspendCancellableCoroutine
        }
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.US
                isReady = true
                cont.resume(tts!!)
            } else {
                cont.resumeWithException(IllegalStateException("Text-to-Speech engine failed to initialize on this device."))
            }
        }
    }

    /**
     * Synthesizes [text] to a .wav file in the app's cache directory and returns the file.
     */
    suspend fun synthesizeToFile(text: String): Result<File> {
        return try {
            val engine = ensureInitialized()
            val outputFile = File(context.cacheDir, "voiceover_${UUID.randomUUID()}.wav")
            val utteranceId = UUID.randomUUID().toString()

            suspendCancellableCoroutine<Unit> { cont ->
                engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        if (cont.isActive) cont.resume(Unit)
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        if (cont.isActive) cont.resumeWithException(IllegalStateException("TTS synthesis failed."))
                    }
                })
                val result = engine.synthesizeToFile(text, null, outputFile, utteranceId)
                if (result != TextToSpeech.SUCCESS && cont.isActive) {
                    cont.resumeWithException(IllegalStateException("TTS synthesis could not start."))
                }
            }
            Result.success(outputFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isReady = false
    }
}
