package com.facelessstudio.ai.ui.screens.social

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.facelessstudio.ai.domain.model.SocialPlatform
import com.facelessstudio.ai.ui.theme.NeonBlue
import com.facelessstudio.ai.ui.theme.SuccessGreen

/**
 * "Connected Accounts" hub — lives inside Settings. Each platform row opens
 * its own dedicated settings screen (auto-publish, default visibility,
 * watermark, etc.) so every platform's configuration stays independent.
 */
@Composable
fun SocialConnectionsScreen(
    onOpenPlatformSettings: (SocialPlatform) -> Unit,
    viewModel: SocialConnectionsViewModel = hiltViewModel()
) {
    val accounts by viewModel.accounts.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Connected Accounts", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Manage where your generated videos publish. Nothing leaves the app without your permission.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(SocialPlatform.entries) { platform ->
                val account = accounts[platform]
                PlatformRow(
                    platform = platform,
                    isConnected = account?.isConnected == true,
                    accountName = account?.accountName,
                    onClick = { onOpenPlatformSettings(platform) }
                )
            }
        }
    }
}

@Composable
private fun PlatformRow(
    platform: SocialPlatform,
    isConnected: Boolean,
    accountName: String?,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth().clickable { onClick() }
    ) {
        Row(
            Modifier.padding(16.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(platform.displayName, style = MaterialTheme.typography.titleMedium)
                Text(
                    if (isConnected) accountName ?: "Connected" else "Not connected",
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isConnected) SuccessGreen else Color.Gray
                )
            }
            Icon(
                imageVector = if (isConnected) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (isConnected) SuccessGreen else NeonBlue.copy(alpha = 0.4f)
            )
        }
    }
}
