package com.facelessstudio.ai.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ScheduleStatus { PENDING, PUBLISHING, PUBLISHED, FAILED, CANCELLED }

@Entity(tableName = "scheduled_posts")
data class ScheduledPostEntity(
    @PrimaryKey val id: String,
    val videoFilePath: String,
    val platform: String, // SocialPlatform.name
    val title: String,
    val description: String,
    val scheduledAtEpochMillis: Long,
    val status: String = ScheduleStatus.PENDING.name,
    val resultUrlOrId: String? = null,
    val errorMessage: String? = null
)
