package com.facelessstudio.ai.data.repository

import com.facelessstudio.ai.domain.model.SocialPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Publishes a video Pin using Pinterest's real API v5, which — unlike Instagram/Threads —
 * supports genuine device-file upload (no public hosting needed):
 *  1. POST /v5/media to register an upload, getting back an upload_url + form parameters
 *  2. POST the video file (multipart) to that upload_url using those exact parameters
 *  3. Poll GET /v5/media/{id} until Pinterest finishes processing
 *  4. POST /v5/pins referencing the finished media_id + the chosen board
 */
@Singleton
class PinterestUploadRepository @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val oauthRepository: OAuthRepository,
    private val boardRepository: PinterestBoardRepository
) {
    suspend fun upload(
        videoFile: File,
        title: String,
        description: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val token = oauthRepository.validAccessToken(SocialPlatform.PINTEREST)
                ?: return@withContext Result.failure(IllegalStateException("Not connected to Pinterest."))
            val boardId = boardRepository.selectedBoardId()
                ?: return@withContext Result.failure(IllegalStateException("Pick a Pinterest board in Settings first."))

            // Step 1: register the media upload.
            val registerBody = JSONObject().put("media_type", "video")
                .toString()
                .toRequestBody("application/json".toMediaType())
            val registerRequest = Request.Builder()
                .url("https://api.pinterest.com/v5/media")
                .addHeader("Authorization", "Bearer $token")
                .post(registerBody)
                .build()

            val (mediaId, uploadUrl, uploadParams) = okHttpClient.newCall(registerRequest).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Pinterest media registration failed (HTTP ${response.code}): $body"))
                }
                val json = JSONObject(body)
                val id = json.getString("media_id")
                val url = json.getString("upload_url")
                val paramsJson = json.getJSONObject("upload_parameters")
                val params = paramsJson.keys().asSequence().associateWith { paramsJson.getString(it) }
                Triple(id, url, params)
            }

            // Step 2: upload the actual video bytes to the presigned upload URL, including
            // every form field Pinterest gave us (order matters for some storage backends,
            // so the file part is added last).
            val multipartBuilder = MultipartBody.Builder().setType(MultipartBody.FORM)
            uploadParams.forEach { (key, value) -> multipartBuilder.addFormDataPart(key, value) }
            multipartBuilder.addFormDataPart("file", videoFile.name, videoFile.asRequestBody("video/mp4".toMediaType()))

            val uploadRequest = Request.Builder().url(uploadUrl).post(multipartBuilder.build()).build()
            okHttpClient.newCall(uploadRequest).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Pinterest file upload failed (HTTP ${response.code})."))
                }
            }

            // Step 3: poll until Pinterest finishes processing the upload.
            var ready = false
            repeat(20) {
                delay(3000)
                val statusRequest = Request.Builder()
                    .url("https://api.pinterest.com/v5/media/$mediaId")
                    .addHeader("Authorization", "Bearer $token")
                    .build()
                okHttpClient.newCall(statusRequest).execute().use { response ->
                    if (response.isSuccessful) {
                        val status = JSONObject(response.body?.string().orEmpty()).optString("status")
                        when (status) {
                            "succeeded" -> ready = true
                            "failed" -> return@withContext Result.failure(IllegalStateException("Pinterest failed to process the video."))
                        }
                    }
                }
            }
            if (!ready) return@withContext Result.failure(IllegalStateException("Pinterest is still processing — try publishing again shortly."))

            // Step 4: create the Pin referencing the finished media.
            val pinBody = JSONObject().apply {
                put("board_id", boardId)
                put("title", title)
                put("description", description)
                put("media_source", JSONObject().apply {
                    put("source_type", "video_id")
                    put("media_id", mediaId)
                })
            }.toString().toRequestBody("application/json".toMediaType())

            val pinRequest = Request.Builder()
                .url("https://api.pinterest.com/v5/pins")
                .addHeader("Authorization", "Bearer $token")
                .post(pinBody)
                .build()

            okHttpClient.newCall(pinRequest).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Pinterest Pin creation failed (HTTP ${response.code}): $body"))
                }
                val pinId = JSONObject(body).optString("id")
                if (pinId.isBlank()) {
                    Result.failure(IllegalStateException("Pin created but Pinterest returned no ID."))
                } else {
                    Result.success("https://pinterest.com/pin/$pinId")
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
