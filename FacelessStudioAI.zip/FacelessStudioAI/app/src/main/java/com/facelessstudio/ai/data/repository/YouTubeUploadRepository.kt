package com.facelessstudio.ai.data.repository

import com.facelessstudio.ai.domain.model.SocialPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Publishes an exported video straight to YouTube using the real Data API v3
 * resumable upload flow (init request -> upload session URL -> PUT the file bytes).
 * Needs an access token with the youtube.upload scope (see OAuthConfigs.YOUTUBE).
 */
@Singleton
class YouTubeUploadRepository @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val oauthRepository: OAuthRepository
) {
    suspend fun upload(
        videoFile: File,
        title: String,
        description: String,
        privacyStatus: String = "private" // "private" | "unlisted" | "public"
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val accessToken = oauthRepository.validAccessToken(SocialPlatform.YOUTUBE)
                ?: return@withContext Result.failure(IllegalStateException("Not connected to YouTube."))

            val metadata = JSONObject().apply {
                put("snippet", JSONObject().apply {
                    put("title", title)
                    put("description", description)
                })
                put("status", JSONObject().apply {
                    put("privacyStatus", privacyStatus.lowercase())
                })
            }

            // Step 1: initiate the resumable upload session.
            val initRequest = Request.Builder()
                .url("https://www.googleapis.com/upload/youtube/v3/videos?uploadType=resumable&part=snippet,status")
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("X-Upload-Content-Type", "video/mp4")
                .addHeader("X-Upload-Content-Length", videoFile.length().toString())
                .post(metadata.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val uploadUrl = okHttpClient.newCall(initRequest).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(
                        IllegalStateException("Could not start YouTube upload (HTTP ${response.code}): ${response.body?.string()}")
                    )
                }
                response.header("Location")
                    ?: return@withContext Result.failure(IllegalStateException("YouTube did not return an upload session URL."))
            }

            // Step 2: PUT the actual video bytes to the session URL.
            val uploadRequest = Request.Builder()
                .url(uploadUrl)
                .put(videoFile.asRequestBody("video/mp4".toMediaType()))
                .build()

            okHttpClient.newCall(uploadRequest).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("YouTube upload failed (HTTP ${response.code}): $body"))
                }
                val videoId = JSONObject(body).optString("id")
                if (videoId.isBlank()) {
                    Result.failure(IllegalStateException("Upload succeeded but no video ID was returned."))
                } else {
                    Result.success("https://youtube.com/watch?v=$videoId")
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
