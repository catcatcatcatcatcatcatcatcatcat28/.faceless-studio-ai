package com.facelessstudio.ai.ui.screens.create

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.facelessstudio.ai.data.remote.PollinationsImage
import com.facelessstudio.ai.data.repository.ApiKeyRepository
import com.facelessstudio.ai.data.repository.FacebookUploadRepository
import com.facelessstudio.ai.data.repository.ExportScene
import com.facelessstudio.ai.data.repository.PinterestUploadRepository
import com.facelessstudio.ai.data.repository.ScheduleRepository
import com.facelessstudio.ai.data.repository.ScriptRepository
import com.facelessstudio.ai.data.repository.SocialAccountRepository
import com.facelessstudio.ai.data.repository.TikTokUploadRepository
import com.facelessstudio.ai.data.repository.VideoExportRepository
import com.facelessstudio.ai.data.repository.VoiceoverRepository
import com.facelessstudio.ai.data.repository.YouTubeUploadRepository
import com.facelessstudio.ai.domain.model.SocialPlatform
import com.facelessstudio.ai.notifications.NotificationHelper
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File
import javax.inject.Inject

data class Scene(
    val text: String,
    val imageUrl: String
)

sealed class CreateStep {
    data object Idle : CreateStep()
    data object GeneratingScript : CreateStep()
    data object GeneratingVoiceover : CreateStep()
    data object Ready : CreateStep()
    data class Error(val message: String) : CreateStep()
}

sealed class ExportStep {
    data object Idle : ExportStep()
    data object DownloadingImages : ExportStep()
    data class Rendering(val percent: Int) : ExportStep()
    data class Done(val file: File) : ExportStep()
    data class Error(val message: String) : ExportStep()
}

sealed class PublishStep {
    data object Idle : PublishStep()
    data object Uploading : PublishStep()
    data class Done(val videoUrl: String) : PublishStep()
    data class Error(val message: String) : PublishStep()
}

data class CreateVideoUiState(
    val topic: String = "",
    val step: CreateStep = CreateStep.Idle,
    val script: String = "",
    val scenes: List<Scene> = emptyList(),
    val voiceoverFile: File? = null,
    val hasApiKey: Boolean = false,
    val exportStep: ExportStep = ExportStep.Idle,
    val publishStep: PublishStep = PublishStep.Idle,
    val youtubeConnected: Boolean = false,
    val tiktokPublishStep: PublishStep = PublishStep.Idle,
    val tiktokConnected: Boolean = false,
    val facebookPublishStep: PublishStep = PublishStep.Idle,
    val facebookConnected: Boolean = false,
    val pinterestPublishStep: PublishStep = PublishStep.Idle,
    val pinterestConnected: Boolean = false,
    val showScheduleDialog: Boolean = false,
    val scheduleConfirmation: String? = null
)

@HiltViewModel
class CreateVideoViewModel @Inject constructor(
    private val scriptRepository: ScriptRepository,
    private val voiceoverRepository: VoiceoverRepository,
    private val apiKeyRepository: ApiKeyRepository,
    private val videoExportRepository: VideoExportRepository,
    private val youTubeUploadRepository: YouTubeUploadRepository,
    private val tikTokUploadRepository: TikTokUploadRepository,
    private val facebookUploadRepository: FacebookUploadRepository,
    private val pinterestUploadRepository: PinterestUploadRepository,
    private val socialAccountRepository: SocialAccountRepository,
    private val scheduleRepository: ScheduleRepository,
    private val notificationHelper: NotificationHelper
) : ViewModel() {

    private val _uiState = MutableStateFlow(
        CreateVideoUiState(hasApiKey = apiKeyRepository.hasGeminiKey())
    )
    val uiState: StateFlow<CreateVideoUiState> = _uiState

    init {
        viewModelScope.launch {
            socialAccountRepository.accounts.collect { accounts ->
                val youtubeConnected = accounts[SocialPlatform.YOUTUBE]?.isConnected == true
                val tiktokConnected = accounts[SocialPlatform.TIKTOK]?.isConnected == true
                val facebookConnected = accounts[SocialPlatform.FACEBOOK]?.isConnected == true
                val pinterestConnected = accounts[SocialPlatform.PINTEREST]?.isConnected == true
                _uiState.value = _uiState.value.copy(
                    youtubeConnected = youtubeConnected,
                    tiktokConnected = tiktokConnected,
                    facebookConnected = facebookConnected,
                    pinterestConnected = pinterestConnected
                )
            }
        }
    }

    fun updateTopic(topic: String) {
        _uiState.value = _uiState.value.copy(topic = topic)
    }

    fun generate() {
        val topic = _uiState.value.topic.trim()
        if (topic.isBlank()) return

        if (!apiKeyRepository.hasGeminiKey()) {
            _uiState.value = _uiState.value.copy(
                step = CreateStep.Error("Add your free Gemini API key first (Settings → AI & Content Safety).")
            )
            return
        }

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(step = CreateStep.GeneratingScript)

            val scriptResult = scriptRepository.generateScript(topic)
            val script = scriptResult.getOrElse {
                _uiState.value = _uiState.value.copy(step = CreateStep.Error(it.message ?: "Script generation failed."))
                return@launch
            }

            val sceneTexts = scriptRepository.splitIntoScenes(script)
            val scenes = sceneTexts.map { sceneText ->
                Scene(text = sceneText, imageUrl = PollinationsImage.urlFor(sceneText))
            }

            _uiState.value = _uiState.value.copy(
                script = script,
                scenes = scenes,
                step = CreateStep.GeneratingVoiceover
            )

            val voiceResult = voiceoverRepository.synthesizeToFile(script)
            val voiceFile = voiceResult.getOrElse {
                _uiState.value = _uiState.value.copy(step = CreateStep.Error(it.message ?: "Voiceover generation failed."))
                return@launch
            }

            _uiState.value = _uiState.value.copy(
                voiceoverFile = voiceFile,
                step = CreateStep.Ready
            )
        }
    }

    fun refreshApiKeyStatus() {
        _uiState.value = _uiState.value.copy(hasApiKey = apiKeyRepository.hasGeminiKey())
    }

    fun exportVideo() {
        val state = _uiState.value
        val voiceoverFile = state.voiceoverFile
        if (state.scenes.isEmpty() || voiceoverFile == null) return
        if (state.exportStep is ExportStep.DownloadingImages || state.exportStep is ExportStep.Rendering) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(exportStep = ExportStep.DownloadingImages)

            val exportScenes = state.scenes.map { ExportScene(it.text, it.imageUrl) }
            val result = videoExportRepository.exportVideo(exportScenes, voiceoverFile) { progress ->
                val step = when (progress) {
                    is com.facelessstudio.ai.data.repository.VideoExportRepository.ExportProgress.Downloading ->
                        ExportStep.DownloadingImages
                    is com.facelessstudio.ai.data.repository.VideoExportRepository.ExportProgress.Rendering ->
                        ExportStep.Rendering(progress.percent)
                }
                _uiState.value = _uiState.value.copy(exportStep = step)
            }

            result.onSuccess { notificationHelper.notifyExportComplete() }
            result.onFailure { e -> notificationHelper.notifyExportFailed(e.message ?: "Video export failed.") }

            _uiState.value = result.fold(
                onSuccess = { file -> _uiState.value.copy(exportStep = ExportStep.Done(file)) },
                onFailure = { e -> _uiState.value.copy(exportStep = ExportStep.Error(e.message ?: "Video export failed.")) }
            )
        }
    }

    fun dismissExportError() {
        _uiState.value = _uiState.value.copy(exportStep = ExportStep.Idle)
    }

    fun publishToYouTube() {
        val state = _uiState.value
        val exportStep = state.exportStep
        if (exportStep !is ExportStep.Done) return
        if (state.publishStep is PublishStep.Uploading) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(publishStep = PublishStep.Uploading)

            val title = state.topic.take(95).ifBlank { "Faceless Studio video" }
            val description = state.script.take(4900)

            val result = youTubeUploadRepository.upload(
                videoFile = exportStep.file,
                title = title,
                description = description,
                privacyStatus = "private" // safest default; user can change visibility on YouTube after upload
            )

            result.onSuccess { url -> notificationHelper.notifyPublishResult("YouTube", success = true, detail = url) }
            result.onFailure { e -> notificationHelper.notifyPublishResult("YouTube", success = false, detail = e.message ?: "Upload failed.") }

            _uiState.value = _uiState.value.copy(
                publishStep = result.fold(
                    onSuccess = { url -> PublishStep.Done(url) },
                    onFailure = { e -> PublishStep.Error(e.message ?: "Upload to YouTube failed.") }
                )
            )
        }
    }

    fun dismissPublishError() {
        _uiState.value = _uiState.value.copy(publishStep = PublishStep.Idle)
    }

    fun publishToTikTok() {
        val state = _uiState.value
        val exportStep = state.exportStep
        if (exportStep !is ExportStep.Done) return
        if (state.tiktokPublishStep is PublishStep.Uploading) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(tiktokPublishStep = PublishStep.Uploading)

            val title = state.topic.take(150).ifBlank { "Faceless Studio video" }

            val result = tikTokUploadRepository.upload(
                videoFile = exportStep.file,
                title = title,
                privacyLevel = TikTokUploadRepository.PrivacyLevel.PRIVATE // safest default; change in the TikTok app after upload
            )

            result.onSuccess { id -> notificationHelper.notifyPublishResult("TikTok", success = true, detail = "publish_id: $id") }
            result.onFailure { e -> notificationHelper.notifyPublishResult("TikTok", success = false, detail = e.message ?: "Upload failed.") }

            _uiState.value = _uiState.value.copy(
                tiktokPublishStep = result.fold(
                    onSuccess = { publishId -> PublishStep.Done("Uploaded (publish_id: $publishId) — check your TikTok drafts/posts.") },
                    onFailure = { e -> PublishStep.Error(e.message ?: "Upload to TikTok failed.") }
                )
            )
        }
    }

    fun dismissTikTokPublishError() {
        _uiState.value = _uiState.value.copy(tiktokPublishStep = PublishStep.Idle)
    }

    fun publishToFacebook() {
        val state = _uiState.value
        val exportStep = state.exportStep
        if (exportStep !is ExportStep.Done) return
        if (state.facebookPublishStep is PublishStep.Uploading) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(facebookPublishStep = PublishStep.Uploading)

            val title = state.topic.take(95).ifBlank { "Faceless Studio video" }
            val description = state.script.take(4900)

            val result = facebookUploadRepository.upload(exportStep.file, title, description)

            result.onSuccess { url -> notificationHelper.notifyPublishResult("Facebook", success = true, detail = url) }
            result.onFailure { e -> notificationHelper.notifyPublishResult("Facebook", success = false, detail = e.message ?: "Upload failed.") }

            _uiState.value = _uiState.value.copy(
                facebookPublishStep = result.fold(
                    onSuccess = { url -> PublishStep.Done(url) },
                    onFailure = { e -> PublishStep.Error(e.message ?: "Upload to Facebook failed.") }
                )
            )
        }
    }

    fun dismissFacebookPublishError() {
        _uiState.value = _uiState.value.copy(facebookPublishStep = PublishStep.Idle)
    }

    fun publishToPinterest() {
        val state = _uiState.value
        val exportStep = state.exportStep
        if (exportStep !is ExportStep.Done) return
        if (state.pinterestPublishStep is PublishStep.Uploading) return

        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(pinterestPublishStep = PublishStep.Uploading)

            val title = state.topic.take(100).ifBlank { "Faceless Studio video" }
            val description = state.script.take(500)

            val result = pinterestUploadRepository.upload(exportStep.file, title, description)

            result.onSuccess { url -> notificationHelper.notifyPublishResult("Pinterest", success = true, detail = url) }
            result.onFailure { e -> notificationHelper.notifyPublishResult("Pinterest", success = false, detail = e.message ?: "Upload failed.") }

            _uiState.value = _uiState.value.copy(
                pinterestPublishStep = result.fold(
                    onSuccess = { url -> PublishStep.Done(url) },
                    onFailure = { e -> PublishStep.Error(e.message ?: "Upload to Pinterest failed.") }
                )
            )
        }
    }

    fun dismissPinterestPublishError() {
        _uiState.value = _uiState.value.copy(pinterestPublishStep = PublishStep.Idle)
    }

    fun openScheduleDialog() {
        _uiState.value = _uiState.value.copy(showScheduleDialog = true)
    }

    fun dismissScheduleDialog() {
        _uiState.value = _uiState.value.copy(showScheduleDialog = false)
    }

    fun dismissScheduleConfirmation() {
        _uiState.value = _uiState.value.copy(scheduleConfirmation = null)
    }

    /** YouTube, TikTok, Facebook, and Pinterest all have real local-file upload
     * implementations, so those four are the schedulable targets. Instagram and Threads
     * require a publicly-hosted video URL (see their upload repositories) and aren't
     * wired into scheduling yet. */
    fun schedulePost(platform: SocialPlatform, scheduledAtEpochMillis: Long) {
        val state = _uiState.value
        val exportStep = state.exportStep
        if (exportStep !is ExportStep.Done) return

        viewModelScope.launch {
            scheduleRepository.schedule(
                videoFile = exportStep.file,
                platform = platform,
                title = state.topic.take(150).ifBlank { "Faceless Studio video" },
                description = state.script.take(4900),
                scheduledAtEpochMillis = scheduledAtEpochMillis
            )
            _uiState.value = _uiState.value.copy(
                showScheduleDialog = false,
                scheduleConfirmation = "Scheduled for ${platform.displayName}. Track it in Settings → Scheduled Posts."
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceoverRepository.shutdown()
    }
}
