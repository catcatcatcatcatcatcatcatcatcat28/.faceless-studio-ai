package com.facelessstudio.ai.data.repository

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Publishes a video directly to a Facebook Page's video feed via the Graph API
 * (POST /{page-id}/videos, multipart, using the Page access token — not the
 * user token). Requires a Page to already be selected in Facebook's platform
 * settings (MetaPageRepository.selectPage).
 */
@Singleton
class FacebookUploadRepository @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val metaPageRepository: MetaPageRepository
) {
    suspend fun upload(
        videoFile: File,
        title: String,
        description: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val pageId = metaPageRepository.selectedPageId()
                ?: return@withContext Result.failure(IllegalStateException("Pick a Facebook Page in Settings first."))
            val pageToken = metaPageRepository.selectedPageToken()
                ?: return@withContext Result.failure(IllegalStateException("Pick a Facebook Page in Settings first."))

            val requestBody = MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("access_token", pageToken)
                .addFormDataPart("title", title)
                .addFormDataPart("description", description)
                .addFormDataPart("source", videoFile.name, videoFile.asRequestBody("video/mp4".toMediaType()))
                .build()

            val request = Request.Builder()
                .url("https://graph-video.facebook.com/v19.0/$pageId/videos")
                .post(requestBody)
                .build()

            okHttpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Facebook upload failed (HTTP ${response.code}): $body"))
                }
                val videoId = JSONObject(body).optString("id")
                if (videoId.isBlank()) {
                    Result.failure(IllegalStateException("Upload succeeded but Facebook returned no video ID."))
                } else {
                    Result.success("https://www.facebook.com/$pageId/videos/$videoId")
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
