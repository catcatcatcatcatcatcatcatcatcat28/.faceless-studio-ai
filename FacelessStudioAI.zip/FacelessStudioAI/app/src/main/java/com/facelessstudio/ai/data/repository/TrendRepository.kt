package com.facelessstudio.ai.data.repository

import com.facelessstudio.ai.domain.model.TrendSource
import com.facelessstudio.ai.domain.model.TrendTopic
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Free trend sources — no API key, no developer app needed (unlike the social
 * platforms), which is why this doesn't go through OAuthRepository.
 *
 *  - Google Trends' unofficial "daily trends" endpoint (used by many trend-dashboard
 *    apps; response is prefixed with ")]}'," which must be stripped before parsing).
 *  - Reddit's public r/all top-of-day JSON (no auth required for read access,
 *    but Reddit blocks requests without a real User-Agent).
 *
 * Both are best-effort: if one source fails (rate-limited, endpoint shape changed,
 * no network), the other still returns results instead of failing the whole call.
 */
@Singleton
class TrendRepository @Inject constructor(
    private val okHttpClient: OkHttpClient
) {
    suspend fun fetchTrends(regionCode: String = "US"): Result<List<TrendTopic>> = withContext(Dispatchers.IO) {
        coroutineScope {
            val googleDeferred = async { runCatching { fetchGoogleTrends(regionCode) }.getOrDefault(emptyList()) }
            val redditDeferred = async { runCatching { fetchRedditTrends() }.getOrDefault(emptyList()) }

            val combined = googleDeferred.await() + redditDeferred.await()
            if (combined.isEmpty()) {
                Result.failure(IllegalStateException("Could not load trends right now. Check your connection and try again."))
            } else {
                Result.success(combined)
            }
        }
    }

    private fun fetchGoogleTrends(regionCode: String): List<TrendTopic> {
        val url = "https://trends.google.com/trends/api/dailytrends?hl=en-US&tz=-480&geo=$regionCode&ns=15"
        val request = Request.Builder().url(url).addHeader("User-Agent", "Mozilla/5.0").build()

        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return emptyList()
            val raw = response.body?.string() ?: return emptyList()
            // Strip the ")]}'," XSSI-protection prefix Google prepends to this endpoint.
            val jsonText = raw.substringAfter("\n", raw).ifBlank { raw }
            val json = JSONObject(jsonText)
            val days = json.getJSONObject("default").getJSONArray("trendingSearchesDays")
            if (days.length() == 0) return emptyList()
            val searches = days.getJSONObject(0).getJSONArray("trendingSearches")

            return (0 until searches.length()).mapNotNull { i ->
                val item = searches.getJSONObject(i)
                val title = item.getJSONObject("title").optString("query").ifBlank { return@mapNotNull null }
                val traffic = item.optString("formattedTraffic").ifBlank { null }
                val articles = item.optJSONArray("articles")
                val firstArticleTitle = articles?.takeIf { it.length() > 0 }?.getJSONObject(0)?.optString("title")
                TrendTopic(
                    title = title,
                    source = TrendSource.GOOGLE_TRENDS,
                    approxTraffic = traffic?.let { "$it searches" },
                    context = firstArticleTitle
                )
            }
        }
    }

    private fun fetchRedditTrends(): List<TrendTopic> {
        val url = "https://www.reddit.com/r/all/top.json?t=day&limit=15"
        val request = Request.Builder()
            .url(url)
            .addHeader("User-Agent", "FacelessStudioAI/1.0 (Android; trend-discovery)")
            .build()

        okHttpClient.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return emptyList()
            val body = response.body?.string() ?: return emptyList()
            val children = JSONObject(body).getJSONObject("data").getJSONArray("children")

            return (0 until children.length()).mapNotNull { i ->
                val post = children.getJSONObject(i).optJSONObject("data") ?: return@mapNotNull null
                val title = post.optString("title").ifBlank { return@mapNotNull null }
                val subreddit = post.optString("subreddit_name_prefixed")
                val ups = post.optInt("ups", 0)
                TrendTopic(
                    title = title,
                    source = TrendSource.REDDIT,
                    approxTraffic = formatUpvotes(ups),
                    context = subreddit.ifBlank { null },
                    url = "https://reddit.com${post.optString("permalink")}"
                )
            }
        }
    }

    private fun formatUpvotes(ups: Int): String = when {
        ups >= 1000 -> "%.1fk upvotes".format(ups / 1000.0)
        else -> "$ups upvotes"
    }
}
