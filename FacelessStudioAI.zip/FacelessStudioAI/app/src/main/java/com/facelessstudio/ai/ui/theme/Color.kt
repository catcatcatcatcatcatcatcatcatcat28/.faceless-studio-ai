package com.facelessstudio.ai.ui.theme

import androidx.compose.ui.graphics.Color

// Intergalactic / glassmorphism palette
val SpaceBlack = Color(0xFF06060C)
val GlassSurface = Color(0xCC12121E) // translucent panel
val NeonBlue = Color(0xFF3DD9FF)
val NeonBluePale = Color(0xFF9FF0FF)
val NebulaPurple = Color(0xFF8B5CF6)
val NebulaPurpleDeep = Color(0xFF4C1D95)
val StarWhite = Color(0xFFF5F6FF)
val MutedGray = Color(0xFF8A8AA3)
val DangerRed = Color(0xFFFF5C7A)
val SuccessGreen = Color(0xFF43F5A0)

// Per-platform brand accents (used only for small identifying badges, not full theming)
val YouTubeRed = Color(0xFFFF0033)
val TikTokTeal = Color(0xFF25F4EE)
val FacebookBlue = Color(0xFF1877F2)
val InstagramPink = Color(0xFFE1306C)
