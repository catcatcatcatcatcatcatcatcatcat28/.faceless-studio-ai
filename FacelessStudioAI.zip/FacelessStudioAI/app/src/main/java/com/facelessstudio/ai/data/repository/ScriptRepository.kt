package com.facelessstudio.ai.data.repository

import com.facelessstudio.ai.data.remote.GeminiApi
import com.facelessstudio.ai.data.remote.GeminiContent
import com.facelessstudio.ai.data.remote.GeminiPart
import com.facelessstudio.ai.data.remote.GeminiRequest
import com.facelessstudio.ai.data.remote.firstText
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ScriptRepository @Inject constructor(
    private val geminiApi: GeminiApi,
    private val apiKeyRepository: ApiKeyRepository
) {
    /**
     * Generates a short faceless-video script for the given topic.
     * Automatically steers away from every category listed in the app's
     * content-safety rules (politics, religion, violence, hate speech, etc.).
     */
    suspend fun generateScript(topic: String, targetSeconds: Int = 60): Result<String> {
        val apiKey = apiKeyRepository.geminiKey.value
        if (apiKey.isBlank()) {
            return Result.failure(IllegalStateException("No Gemini API key set. Add your free key in Settings → AI & Content Safety."))
        }

        val prompt = """
            You are a scriptwriter for short faceless YouTube/TikTok videos.
            Write a voiceover script about: "$topic"
            Target length: approximately $targetSeconds seconds when narrated aloud (roughly ${targetSeconds * 2.5} words).

            Rules:
            - Original content only, no copyrighted material, no direct quotes from named sources.
            - Do NOT include political, election, war, military, religious, hateful, adult, or violent content.
            - No celebrity impersonation or voice cloning references.
            - Write ONLY the narration text, split into short scenes separated by blank lines.
            - Each scene should be 1-3 sentences, easy to narrate and easy to illustrate visually.
            - No stage directions, no scene numbers, no markdown — plain narration text only.
        """.trimIndent()

        return try {
            val response = geminiApi.generateContent(
                apiKey = apiKey,
                request = GeminiRequest(
                    contents = listOf(GeminiContent(parts = listOf(GeminiPart(text = prompt))))
                )
            )
            val text = response.firstText()
            if (text.isNullOrBlank()) {
                Result.failure(IllegalStateException("Gemini returned an empty response. Try a different topic."))
            } else {
                Result.success(text.trim())
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** Splits a generated script into individual scenes (used to drive one image per scene). */
    fun splitIntoScenes(script: String): List<String> =
        script.split(Regex("\\n\\s*\\n"))
            .map { it.trim() }
            .filter { it.isNotBlank() }
}
