package com.facelessstudio.ai.ui.screens.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.facelessstudio.ai.data.repository.ApiKeyRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ApiKeySettingsViewModel @Inject constructor(
    private val repository: ApiKeyRepository
) : ViewModel() {
    val currentKey = repository.geminiKey

    fun save(key: String) = viewModelScope.launch {
        repository.saveGeminiKey(key.trim())
    }
}

@Composable
fun ApiKeySettingsScreen(
    onBack: () -> Unit,
    viewModel: ApiKeySettingsViewModel = hiltViewModel()
) {
    val savedKey by viewModel.currentKey.collectAsState()
    var input by remember(savedKey) { mutableStateOf(savedKey) }
    var showKey by remember { mutableStateOf(false) }
    val uriHandler = LocalUriHandler.current

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }
        Text("AI & Content Safety", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Gemini API Key", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Free, no credit card required. Powers script generation.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text("API Key") },
                    singleLine = true,
                    visualTransformation = if (showKey) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )
                Row(Modifier.padding(top = 4.dp)) {
                    TextButton(onClick = { showKey = !showKey }) {
                        Text(if (showKey) "Hide" else "Show")
                    }
                }
                Spacer(Modifier.height(8.dp))
                Button(onClick = { viewModel.save(input) }, enabled = input.isNotBlank()) {
                    Text("Save Key")
                }
                Spacer(Modifier.height(12.dp))
                TextButton(onClick = { uriHandler.openUri("https://aistudio.google.com/app/apikey") }) {
                    Text("Get a free key at aistudio.google.com →")
                }
            }
        }

        Spacer(Modifier.height(24.dp))
        Text("Content Safety Rules (always on)", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        listOf(
            "Political, election & war content", "Religious preaching", "Hate speech & violence",
            "Adult content", "Celebrity voice cloning", "Copyright infringement or plagiarism"
        ).forEach {
            Text("• Blocked: $it", style = MaterialTheme.typography.bodyMedium)
        }
    }
}
