package com.facelessstudio.ai.ui.screens.trends

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.facelessstudio.ai.domain.model.TrendSource
import com.facelessstudio.ai.domain.model.TrendTopic
import com.facelessstudio.ai.ui.theme.NeonBlue
import com.facelessstudio.ai.ui.theme.NebulaPurple

@Composable
fun TrendDiscoveryScreen(
    onUseTrendAsTopic: (String) -> Unit,
    onBack: () -> Unit,
    viewModel: TrendDiscoveryViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = onBack) { Text("← Back") }
            IconButton(onClick = viewModel::refresh) {
                Icon(Icons.Filled.Refresh, contentDescription = "Refresh trends")
            }
        }

        Text("Trend Discovery", style = MaterialTheme.typography.headlineMedium)
        Text(
            "What's trending right now, pulled fresh from Google Trends and Reddit. Tap a topic to use it as your next video.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
            modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
        )

        when (val s = state) {
            is TrendsUiState.Loading -> {
                Box(Modifier.fillMaxWidth().padding(top = 48.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator()
                }
            }
            is TrendsUiState.Error -> {
                Column(Modifier.padding(top = 32.dp)) {
                    Text(s.message, color = MaterialTheme.colorScheme.error)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = viewModel::refresh) { Text("Try Again") }
                }
            }
            is TrendsUiState.Loaded -> {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(s.trends) { trend ->
                        TrendRow(trend = trend, onClick = { onUseTrendAsTopic(trend.title) })
                    }
                }
            }
        }
    }
}

@Composable
private fun TrendRow(trend: TrendTopic, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        modifier = Modifier.fillMaxWidth().clickable { onClick() }
    ) {
        Row(Modifier.padding(14.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.TrendingUp,
                contentDescription = null,
                tint = if (trend.source == TrendSource.GOOGLE_TRENDS) NeonBlue else NebulaPurple
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(trend.title, style = MaterialTheme.typography.titleMedium)
                val subtitleParts = listOfNotNull(trend.source.displayName, trend.approxTraffic, trend.context)
                if (subtitleParts.isNotEmpty()) {
                    Text(
                        subtitleParts.joinToString(" · "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}
