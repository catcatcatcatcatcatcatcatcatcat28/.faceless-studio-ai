package com.facelessstudio.ai.ui.screens.social

import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.facelessstudio.ai.data.oauth.OAuthConfigs
import com.facelessstudio.ai.domain.model.SocialPlatform

/**
 * Dedicated settings screen for a single platform. Reached from
 * SocialConnectionsScreen by tapping a platform row. Each platform has its
 * own independent connect/disconnect action and publishing preferences —
 * changing one platform never touches another's settings.
 *
 * Connecting launches that platform's real OAuth consent screen (Custom Tabs).
 * This requires a Client ID (and, for some platforms, a Client Secret) from your
 * own developer app registered on that platform — same "bring your own
 * credentials" pattern as the Gemini API key.
 */
@Composable
fun PlatformSettingsScreen(
    platform: SocialPlatform,
    onBack: () -> Unit,
    viewModel: SocialConnectionsViewModel = hiltViewModel()
) {
    val accounts by viewModel.accounts.collectAsState()
    val account = accounts[platform]
    val isConnected = account?.isConnected == true
    val isConnecting by viewModel.isConnecting.collectAsState()
    val connectError by viewModel.connectError.collectAsState()
    val context = LocalContext.current
    val config = OAuthConfigs.byPlatform[platform]

    var clientId by remember(platform) { mutableStateOf(viewModel.clientId(platform)) }
    var clientSecret by remember(platform) { mutableStateOf(viewModel.clientSecret(platform)) }

    var showVisibilityMenu by remember { mutableStateOf(false) }
    val visibilityOptions = listOf("Public", "Unlisted", "Private", "Draft")

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }

        Text(platform.displayName, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        if (!isConnected) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Text("Developer App Credentials", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Register an app on ${platform.displayName}'s developer console to get these. " +
                            "Set the redirect URI there to: ${OAuthConfigs.REDIRECT_URI}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = clientId,
                        onValueChange = { clientId = it },
                        label = { Text("Client ID") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (config?.requiresClientSecret == true) {
                        Spacer(Modifier.height(8.dp))
                        OutlinedTextField(
                            value = clientSecret,
                            onValueChange = { clientSecret = it },
                            label = { Text("Client Secret") },
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(onClick = { viewModel.saveClientCredentials(platform, clientId, clientSecret) }) {
                        Text("Save Credentials")
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    if (isConnected) "Connected as ${account?.accountName}" else "Not connected",
                    style = MaterialTheme.typography.titleMedium
                )
                if (connectError != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(connectError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        if (isConnected) {
                            viewModel.disconnect(platform)
                        } else {
                            val activity = context as? Activity
                            if (activity != null) viewModel.connect(activity, platform)
                        }
                    },
                    enabled = !isConnecting
                ) {
                    if (isConnecting) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Connecting...")
                    } else {
                        Text(if (isConnected) "Disconnect" else "Connect ${platform.displayName}")
                    }
                }
            }
        }

        if (isConnected && platform == SocialPlatform.FACEBOOK) {
            Spacer(Modifier.height(16.dp))
            FacebookPageSection(viewModel)
        }

        if (isConnected && platform == SocialPlatform.INSTAGRAM) {
            Spacer(Modifier.height(16.dp))
            InstagramAdvancedPublishSection(viewModel)
        }

        if (isConnected && platform == SocialPlatform.PINTEREST) {
            Spacer(Modifier.height(16.dp))
            PinterestBoardSection(viewModel)
        }

        if (isConnected && platform == SocialPlatform.THREADS) {
            Spacer(Modifier.height(16.dp))
            ThreadsAdvancedPublishSection(viewModel)
        }

        if (isConnected) {
            Spacer(Modifier.height(24.dp))
            Text("Publishing Preferences", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Auto-publish after export")
                Switch(checked = account?.autoPublishEnabled == true, onCheckedChange = { viewModel.setAutoPublish(platform, it) })
            }

            Spacer(Modifier.height(12.dp))

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Include watermark")
                Switch(checked = account?.includeWatermark == true, onCheckedChange = { viewModel.setWatermark(platform, it) })
            }

            Spacer(Modifier.height(12.dp))

            Box {
                OutlinedButton(onClick = { showVisibilityMenu = true }) {
                    Text("Default visibility: ${account?.defaultVisibility}")
                }
                DropdownMenu(expanded = showVisibilityMenu, onDismissRequest = { showVisibilityMenu = false }) {
                    visibilityOptions.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option) },
                            onClick = {
                                viewModel.setVisibility(platform, option)
                                showVisibilityMenu = false
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FacebookPageSection(viewModel: SocialConnectionsViewModel) {
    val managedPages by viewModel.managedPages.collectAsState()
    val isLoading by viewModel.isLoadingPages.collectAsState()
    val pagesError by viewModel.pagesError.collectAsState()
    var selectedPageName by remember { mutableStateOf(viewModel.selectedPageName()) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Posting As", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                selectedPageName ?: "No Page selected yet — pick which Facebook Page to publish to.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { viewModel.loadManagedPages() }, enabled = !isLoading) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                }
                Text("Choose Page")
            }
            pagesError?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            if (managedPages.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                managedPages.forEach { page ->
                    TextButton(onClick = {
                        viewModel.choosePage(page)
                        selectedPageName = page.name
                    }) {
                        Text(page.name + if (page.instagramBusinessAccountId != null) " (Instagram linked)" else "")
                    }
                }
            }
        }
    }
}

@Composable
private fun PinterestBoardSection(viewModel: SocialConnectionsViewModel) {
    val boards by viewModel.pinterestBoards.collectAsState()
    val isLoading by viewModel.isLoadingBoards.collectAsState()
    val boardsError by viewModel.boardsError.collectAsState()
    var selectedBoardName by remember { mutableStateOf(viewModel.selectedBoardName()) }

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Posting Board", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                selectedBoardName ?: "No board selected yet — pick which Pinterest board to pin to.",
                style = MaterialTheme.typography.bodyMedium
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { viewModel.loadPinterestBoards() }, enabled = !isLoading) {
                if (isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                }
                Text("Choose Board")
            }
            boardsError?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
            if (boards.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                boards.forEach { board ->
                    TextButton(onClick = {
                        viewModel.chooseBoard(board)
                        selectedBoardName = board.name
                    }) {
                        Text(board.name)
                    }
                }
            }
        }
    }
}

@Composable
private fun ThreadsAdvancedPublishSection(viewModel: SocialConnectionsViewModel) {
    var videoUrl by remember { mutableStateOf("") }
    var text by remember { mutableStateOf("") }
    val publishing by viewModel.threadsPublishing.collectAsState()
    val result by viewModel.threadsPublishResult.collectAsState()

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Publish (Advanced)", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                "Threads runs on the same Meta publishing infrastructure as Instagram, so it has the same " +
                    "requirement: a publicly-hosted video URL, not a direct upload from your device. Host your " +
                    "exported video somewhere reachable, then paste that URL here.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = videoUrl,
                onValueChange = { videoUrl = it },
                label = { Text("Public video URL") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text("Post text") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { viewModel.publishToThreads(videoUrl, text) },
                enabled = videoUrl.isNotBlank() && !publishing
            ) {
                if (publishing) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Publishing...")
                } else {
                    Text("Publish to Threads")
                }
            }
            result?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun InstagramAdvancedPublishSection(viewModel: SocialConnectionsViewModel) {
    var videoUrl by remember { mutableStateOf("") }
    var caption by remember { mutableStateOf("") }
    val publishing by viewModel.instagramPublishing.collectAsState()
    val result by viewModel.instagramPublishResult.collectAsState()

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Publish (Advanced)", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(4.dp))
            Text(
                "Instagram's API only accepts a publicly-hosted video URL — it can't pull directly from your " +
                    "device the way YouTube/TikTok/Facebook do. Host your exported video somewhere reachable " +
                    "(a storage bucket, CDN, etc.), then paste that URL here.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = videoUrl,
                onValueChange = { videoUrl = it },
                label = { Text("Public video URL") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = caption,
                onValueChange = { caption = it },
                label = { Text("Caption") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { viewModel.publishToInstagram(videoUrl, caption) },
                enabled = videoUrl.isNotBlank() && !publishing
            ) {
                if (publishing) {
                    CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                    Spacer(Modifier.width(8.dp))
                    Text("Publishing...")
                } else {
                    Text("Publish Reel")
                }
            }
            result?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
