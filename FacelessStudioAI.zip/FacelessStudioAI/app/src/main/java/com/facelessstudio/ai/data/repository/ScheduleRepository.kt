package com.facelessstudio.ai.data.repository

import android.content.Context
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.facelessstudio.ai.data.local.ScheduleStatus
import com.facelessstudio.ai.data.local.ScheduledPostDao
import com.facelessstudio.ai.data.local.ScheduledPostEntity
import com.facelessstudio.ai.domain.model.SocialPlatform
import com.facelessstudio.ai.worker.PublishWorker
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import java.util.UUID
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class ScheduleRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val dao: ScheduledPostDao
) {
    val scheduledPosts: Flow<List<ScheduledPostEntity>> = dao.observeAll()

    /** Persists the post and enqueues a WorkManager job to fire at [scheduledAtEpochMillis]. */
    suspend fun schedule(
        videoFile: java.io.File,
        platform: SocialPlatform,
        title: String,
        description: String,
        scheduledAtEpochMillis: Long
    ): String {
        val id = UUID.randomUUID().toString()
        val entity = ScheduledPostEntity(
            id = id,
            videoFilePath = videoFile.absolutePath,
            platform = platform.name,
            title = title,
            description = description,
            scheduledAtEpochMillis = scheduledAtEpochMillis,
            status = ScheduleStatus.PENDING.name
        )
        dao.insert(entity)

        val delayMillis = (scheduledAtEpochMillis - System.currentTimeMillis()).coerceAtLeast(0L)
        val request = OneTimeWorkRequestBuilder<PublishWorker>()
            .setInitialDelay(delayMillis, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf(PublishWorker.KEY_POST_ID to id))
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .setBackoffCriteria(BackoffPolicy.LINEAR, 30, TimeUnit.SECONDS)
            .addTag(workTag(id))
            .build()

        WorkManager.getInstance(context).enqueueUniqueWork(workTag(id), ExistingWorkPolicy.REPLACE, request)
        return id
    }

    suspend fun cancel(postId: String) {
        WorkManager.getInstance(context).cancelUniqueWork(workTag(postId))
        val post = dao.getById(postId) ?: return
        dao.update(post.copy(status = ScheduleStatus.CANCELLED.name))
    }

    private fun workTag(postId: String) = "scheduled_publish_$postId"
}
