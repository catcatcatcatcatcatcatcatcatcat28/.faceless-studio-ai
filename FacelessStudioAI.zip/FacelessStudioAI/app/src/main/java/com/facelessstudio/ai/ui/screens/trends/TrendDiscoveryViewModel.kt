package com.facelessstudio.ai.ui.screens.trends

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.facelessstudio.ai.data.repository.TrendRepository
import com.facelessstudio.ai.domain.model.TrendTopic
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

sealed class TrendsUiState {
    data object Loading : TrendsUiState()
    data class Loaded(val trends: List<TrendTopic>) : TrendsUiState()
    data class Error(val message: String) : TrendsUiState()
}

@HiltViewModel
class TrendDiscoveryViewModel @Inject constructor(
    private val trendRepository: TrendRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow<TrendsUiState>(TrendsUiState.Loading)
    val uiState: StateFlow<TrendsUiState> = _uiState

    init {
        refresh()
    }

    fun refresh() {
        viewModelScope.launch {
            _uiState.value = TrendsUiState.Loading
            val result = trendRepository.fetchTrends()
            _uiState.value = result.fold(
                onSuccess = { TrendsUiState.Loaded(it) },
                onFailure = { e -> TrendsUiState.Error(e.message ?: "Could not load trends.") }
            )
        }
    }
}
