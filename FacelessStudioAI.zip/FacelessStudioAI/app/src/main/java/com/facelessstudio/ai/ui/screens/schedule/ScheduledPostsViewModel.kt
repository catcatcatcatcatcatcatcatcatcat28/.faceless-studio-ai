package com.facelessstudio.ai.ui.screens.schedule

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.facelessstudio.ai.data.local.ScheduledPostEntity
import com.facelessstudio.ai.data.repository.ScheduleRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ScheduledPostsViewModel @Inject constructor(
    private val scheduleRepository: ScheduleRepository
) : ViewModel() {

    val scheduledPosts: StateFlow<List<ScheduledPostEntity>> = scheduleRepository.scheduledPosts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun cancel(postId: String) = viewModelScope.launch {
        scheduleRepository.cancel(postId)
    }
}
