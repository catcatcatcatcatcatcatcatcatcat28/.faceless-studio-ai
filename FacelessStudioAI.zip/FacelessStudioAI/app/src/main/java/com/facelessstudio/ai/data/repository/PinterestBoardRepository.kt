package com.facelessstudio.ai.data.repository

import com.facelessstudio.ai.domain.model.SocialPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

data class PinterestBoard(val id: String, val name: String)

@Singleton
class PinterestBoardRepository @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val oauthRepository: OAuthRepository,
    private val credentialsRepository: OAuthCredentialsRepository
) {
    suspend fun fetchBoards(): Result<List<PinterestBoard>> = withContext(Dispatchers.IO) {
        try {
            val token = oauthRepository.validAccessToken(SocialPlatform.PINTEREST)
                ?: return@withContext Result.failure(IllegalStateException("Not connected to Pinterest."))

            val request = Request.Builder()
                .url("https://api.pinterest.com/v5/boards?page_size=100")
                .addHeader("Authorization", "Bearer $token")
                .build()

            okHttpClient.newCall(request).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Could not list Pinterest boards (HTTP ${response.code}): $body"))
                }
                val items = JSONObject(body).getJSONArray("items")
                val boards = (0 until items.length()).map { i ->
                    val b = items.getJSONObject(i)
                    PinterestBoard(id = b.getString("id"), name = b.getString("name"))
                }
                Result.success(boards)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun selectBoard(board: PinterestBoard) {
        credentialsRepository.saveExtra(SocialPlatform.PINTEREST, "board_id", board.id)
        credentialsRepository.saveExtra(SocialPlatform.PINTEREST, "board_name", board.name)
    }

    fun selectedBoardId(): String? = credentialsRepository.extra(SocialPlatform.PINTEREST, "board_id")
    fun selectedBoardName(): String? = credentialsRepository.extra(SocialPlatform.PINTEREST, "board_name")
}
