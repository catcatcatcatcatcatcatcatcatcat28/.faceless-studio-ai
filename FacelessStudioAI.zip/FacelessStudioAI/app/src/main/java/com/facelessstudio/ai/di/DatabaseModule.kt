package com.facelessstudio.ai.di

import android.content.Context
import androidx.room.Room
import com.facelessstudio.ai.data.local.AppDatabase
import com.facelessstudio.ai.data.local.ScheduledPostDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "faceless_studio.db").build()

    @Provides
    @Singleton
    fun provideScheduledPostDao(db: AppDatabase): ScheduledPostDao = db.scheduledPostDao()
}
