package com.facelessstudio.ai.data.repository

import com.facelessstudio.ai.domain.model.SocialPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Publishes an exported video to TikTok using the real Content Posting API v2
 * (https://developers.tiktok.com/doc/content-posting-api-reference-direct-post).
 *
 * Flow: init the post (declares total size as a single chunk, since our exported
 * clips are short) -> PUT the raw video bytes to the returned upload_url -> poll
 * publish status until TikTok finishes processing.
 *
 * Requires a TikTok developer app with the Content Posting API product approved
 * and the video.publish (or video.upload for draft-only) scope granted during OAuth.
 */
@Singleton
class TikTokUploadRepository @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val oauthRepository: OAuthRepository
) {
    enum class PrivacyLevel(val apiValue: String) {
        PUBLIC("PUBLIC_TO_EVERYONE"),
        FRIENDS("MUTUAL_FOLLOW_FRIENDS"),
        PRIVATE("SELF_ONLY")
    }

    suspend fun upload(
        videoFile: File,
        title: String,
        privacyLevel: PrivacyLevel = PrivacyLevel.PRIVATE,
        disableComments: Boolean = false,
        onStatus: (String) -> Unit = {}
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val accessToken = oauthRepository.validAccessToken(SocialPlatform.TIKTOK)
                ?: return@withContext Result.failure(IllegalStateException("Not connected to TikTok."))

            val videoSize = videoFile.length()

            // Step 1: initialize the post — single-chunk upload since faceless clips are short.
            val initBody = JSONObject().apply {
                put("post_info", JSONObject().apply {
                    put("title", title.take(150))
                    put("privacy_level", privacyLevel.apiValue)
                    put("disable_comment", disableComments)
                    put("disable_duet", false)
                    put("disable_stitch", false)
                })
                put("source_info", JSONObject().apply {
                    put("source", "FILE_UPLOAD")
                    put("video_size", videoSize)
                    put("chunk_size", videoSize)
                    put("total_chunk_count", 1)
                })
            }

            val initRequest = Request.Builder()
                .url("https://open.tiktokapis.com/v2/post/publish/video/init/")
                .addHeader("Authorization", "Bearer $accessToken")
                .addHeader("Content-Type", "application/json; charset=UTF-8")
                .post(initBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val (publishId, uploadUrl) = okHttpClient.newCall(initRequest).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Could not start TikTok upload (HTTP ${response.code}): $body"))
                }
                val json = JSONObject(body)
                val error = json.optJSONObject("error")
                if (error != null && error.optString("code") != "ok") {
                    return@withContext Result.failure(IllegalStateException("TikTok init error: ${error.optString("message")}"))
                }
                val data = json.getJSONObject("data")
                data.getString("publish_id") to data.getString("upload_url")
            }

            onStatus("Uploading...")

            // Step 2: PUT the video bytes for the single declared chunk.
            val uploadRequest = Request.Builder()
                .url(uploadUrl)
                .addHeader("Content-Range", "bytes 0-${videoSize - 1}/$videoSize")
                .addHeader("Content-Type", "video/mp4")
                .put(videoFile.asRequestBody("video/mp4".toMediaType()))
                .build()

            okHttpClient.newCall(uploadRequest).execute().use { response ->
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("TikTok video upload failed (HTTP ${response.code}): ${response.body?.string()}"))
                }
            }

            // Step 3: poll publish status until TikTok finishes processing (or fails).
            onStatus("Processing on TikTok...")
            repeat(20) { attempt ->
                delay(3000)
                val statusBody = JSONObject().put("publish_id", publishId)
                val statusRequest = Request.Builder()
                    .url("https://open.tiktokapis.com/v2/post/publish/status/fetch/")
                    .addHeader("Authorization", "Bearer $accessToken")
                    .addHeader("Content-Type", "application/json; charset=UTF-8")
                    .post(statusBody.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                okHttpClient.newCall(statusRequest).execute().use { response ->
                    if (response.isSuccessful) {
                        val data = JSONObject(response.body?.string().orEmpty()).optJSONObject("data")
                        val status = data?.optString("status")
                        when (status) {
                            "PUBLISH_COMPLETE" -> return@withContext Result.success(publishId)
                            "FAILED" -> return@withContext Result.failure(
                                IllegalStateException("TikTok processing failed: ${data.optString("fail_reason")}")
                            )
                            else -> onStatus("Processing on TikTok... ($status)")
                        }
                    }
                }
            }

            Result.failure(IllegalStateException("TikTok is still processing the video — check the TikTok app shortly."))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
