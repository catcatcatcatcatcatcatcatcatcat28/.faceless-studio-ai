package com.facelessstudio.ai.data.repository

import android.app.Activity
import android.content.Context
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent
import com.facelessstudio.ai.data.oauth.OAuthConfigs
import com.facelessstudio.ai.data.oauth.PkceUtil
import com.facelessstudio.ai.domain.model.SocialPlatform
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Drives one OAuth 2.0 Authorization Code (+ PKCE where supported) flow at a time.
 *
 * Flow:
 *  1. [beginAuth] builds the authorize URL and opens it in a Custom Tab.
 *  2. The platform redirects to facelessstudio://oauth-callback?code=...&state=...
 *     (declared in the manifest), which MainActivity.onNewIntent forwards to
 *     [handleRedirect].
 *  3. [handleRedirect] validates state, exchanges the code for tokens, and completes
 *     the CompletableDeferred that [beginAuth]'s caller is suspending on.
 */
@Singleton
class OAuthRepository @Inject constructor(
    @ApplicationContext private val context: Context,
    private val okHttpClient: OkHttpClient,
    private val credentialsRepository: OAuthCredentialsRepository,
    private val socialAccountRepository: SocialAccountRepository
) {
    private data class PendingAuth(
        val platform: SocialPlatform,
        val state: String,
        val codeVerifier: String?,
        val deferred: CompletableDeferred<Result<Unit>>
    )

    private var pending: PendingAuth? = null

    /** Launches the platform's consent screen. Suspends until the redirect is handled or fails. */
    suspend fun beginAuth(activity: Activity, platform: SocialPlatform): Result<Unit> {
        val config = OAuthConfigs.byPlatform[platform]
            ?: return Result.failure(IllegalStateException("No OAuth config for $platform yet."))
        val clientId = credentialsRepository.clientId(platform)
        if (clientId.isBlank()) {
            return Result.failure(IllegalStateException("Add a Client ID for ${platform.displayName} first."))
        }

        val state = PkceUtil.generateState()
        val codeVerifier = if (config.usesPkce) PkceUtil.generateCodeVerifier() else null
        val deferred = CompletableDeferred<Result<Unit>>()
        pending = PendingAuth(platform, state, codeVerifier, deferred)

        val uriBuilder = Uri.parse(config.authEndpoint).buildUpon()
            .appendQueryParameter("client_id", clientId)
            .appendQueryParameter("redirect_uri", OAuthConfigs.REDIRECT_URI)
            .appendQueryParameter("response_type", "code")
            .appendQueryParameter("scope", config.scope)
            .appendQueryParameter("state", state)
        if (codeVerifier != null) {
            uriBuilder
                .appendQueryParameter("code_challenge", PkceUtil.generateCodeChallenge(codeVerifier))
                .appendQueryParameter("code_challenge_method", "S256")
        }
        config.extraAuthParams.forEach { (k, v) -> uriBuilder.appendQueryParameter(k, v) }

        CustomTabsIntent.Builder().build().launchUrl(activity, uriBuilder.build())

        return deferred.await()
    }

    /** Called from MainActivity.onNewIntent when the facelessstudio://oauth-callback deep link fires. */
    fun handleRedirect(uri: Uri) {
        val current = pending ?: return
        val error = uri.getQueryParameter("error")
        val returnedState = uri.getQueryParameter("state")
        val code = uri.getQueryParameter("code")

        if (error != null) {
            current.deferred.complete(Result.failure(IllegalStateException("Authorization denied: $error")))
            pending = null
            return
        }
        if (returnedState != current.state) {
            current.deferred.complete(Result.failure(IllegalStateException("OAuth state mismatch — possible tampering, aborted.")))
            pending = null
            return
        }
        if (code.isNullOrBlank()) {
            current.deferred.complete(Result.failure(IllegalStateException("No authorization code returned.")))
            pending = null
            return
        }

        pending = null
        exchangeCodeAsync(current, code)
    }

    private fun exchangeCodeAsync(pendingAuth: PendingAuth, code: String) {
        // Fire-and-forget coroutine off the UI thread; completes the original deferred.
        CoroutineScope(Dispatchers.IO).launch {
            val result = exchangeCode(pendingAuth.platform, code, pendingAuth.codeVerifier)
            pendingAuth.deferred.complete(result)
        }
    }

    private suspend fun exchangeCode(
        platform: SocialPlatform,
        code: String,
        codeVerifier: String?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val config = OAuthConfigs.byPlatform.getValue(platform)
            val clientId = credentialsRepository.clientId(platform)
            val clientSecret = credentialsRepository.clientSecret(platform)

            val formBuilder = FormBody.Builder()
                .add("client_id", clientId)
                .add("code", code)
                .add("grant_type", "authorization_code")
                .add("redirect_uri", OAuthConfigs.REDIRECT_URI)
            if (codeVerifier != null) formBuilder.add("code_verifier", codeVerifier)
            if (config.requiresClientSecret && clientSecret.isNotBlank()) formBuilder.add("client_secret", clientSecret)

            val request = Request.Builder()
                .url(config.tokenEndpoint)
                .post(formBuilder.build())
                .build()

            okHttpClient.newCall(request).execute().use { response ->
                val bodyString = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Token exchange failed (HTTP ${response.code}): $bodyString"))
                }
                val json = JSONObject(bodyString)
                val accessToken = json.optString("access_token").ifBlank {
                    return@withContext Result.failure(IllegalStateException("No access_token in response."))
                }
                val refreshToken = json.optString("refresh_token").ifBlank { null }
                val expiresInSeconds = json.optLong("expires_in", 3600L)
                val expiresAt = System.currentTimeMillis() + expiresInSeconds * 1000L

                credentialsRepository.saveTokens(platform, OAuthTokens(accessToken, refreshToken, expiresAt))
                socialAccountRepository.connect(platform, accountName = "${platform.displayName} account")
                Result.success(Unit)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun disconnect(platform: SocialPlatform) {
        credentialsRepository.clearTokens(platform)
        socialAccountRepository.disconnect(platform)
    }

    /** Returns a currently-valid access token, refreshing it first if it has expired. */
    suspend fun validAccessToken(platform: SocialPlatform): String? = withContext(Dispatchers.IO) {
        val tokens = credentialsRepository.tokens(platform) ?: return@withContext null
        val stillValid = System.currentTimeMillis() < tokens.expiresAtEpochMillis - 60_000L
        if (stillValid) return@withContext tokens.accessToken

        val refreshToken = tokens.refreshToken ?: return@withContext tokens.accessToken
        refreshAccessToken(platform, refreshToken)
    }

    private suspend fun refreshAccessToken(platform: SocialPlatform, refreshToken: String): String? =
        withContext(Dispatchers.IO) {
            try {
                val config = OAuthConfigs.byPlatform.getValue(platform)
                val clientId = credentialsRepository.clientId(platform)
                val clientSecret = credentialsRepository.clientSecret(platform)

                val formBuilder = FormBody.Builder()
                    .add("client_id", clientId)
                    .add("refresh_token", refreshToken)
                    .add("grant_type", "refresh_token")
                if (config.requiresClientSecret && clientSecret.isNotBlank()) formBuilder.add("client_secret", clientSecret)

                val request = Request.Builder().url(config.tokenEndpoint).post(formBuilder.build()).build()
                okHttpClient.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) return@withContext null
                    val json = JSONObject(response.body?.string().orEmpty())
                    val newAccessToken = json.optString("access_token").ifBlank { return@withContext null }
                    val newRefreshToken = json.optString("refresh_token").ifBlank { refreshToken }
                    val expiresInSeconds = json.optLong("expires_in", 3600L)
                    val expiresAt = System.currentTimeMillis() + expiresInSeconds * 1000L
                    credentialsRepository.saveTokens(platform, OAuthTokens(newAccessToken, newRefreshToken, expiresAt))
                    newAccessToken
                }
            } catch (e: Exception) {
                null
            }
        }
}
