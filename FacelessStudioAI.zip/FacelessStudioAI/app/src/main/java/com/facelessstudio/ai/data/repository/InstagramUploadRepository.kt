package com.facelessstudio.ai.data.repository

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Publishes a Reel to Instagram via the Content Publishing API
 * (Meta Graph API: create a media container, poll until Instagram finishes
 * downloading/processing it, then publish the container).
 *
 * IMPORTANT LIMITATION: unlike Facebook/YouTube/TikTok, Instagram's API does
 * NOT accept a raw file upload from a device. The `/media` endpoint only takes
 * a `video_url` — a URL Instagram's own servers can reach and download from.
 * There is no local-file / multipart path in the official API.
 *
 * This app exports videos to local device storage, not to any public host, so
 * this repository can't be wired to a one-tap "Publish to Instagram" button the
 * way YouTube/TikTok/Facebook are. To actually use it, [videoUrl] needs to point
 * to the video hosted somewhere Instagram can fetch it from (e.g. a storage
 * bucket you control) — that hosting step is outside this app's scope for now.
 */
@Singleton
class InstagramUploadRepository @Inject constructor(
    private val okHttpClient: OkHttpClient,
    private val metaPageRepository: MetaPageRepository
) {
    suspend fun upload(
        videoUrl: String,
        caption: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val igUserId = metaPageRepository.linkedInstagramBusinessId()
                ?: return@withContext Result.failure(IllegalStateException("No Instagram Business Account linked to your selected Facebook Page."))
            val pageToken = metaPageRepository.instagramPageToken()
                ?: return@withContext Result.failure(IllegalStateException("Pick a Facebook Page in Settings first."))

            // Step 1: create the media container.
            val createForm = FormBody.Builder()
                .add("media_type", "REELS")
                .add("video_url", videoUrl)
                .add("caption", caption)
                .add("access_token", pageToken)
                .build()
            val createRequest = Request.Builder()
                .url("https://graph.facebook.com/v19.0/$igUserId/media")
                .post(createForm)
                .build()

            val containerId = okHttpClient.newCall(createRequest).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Instagram container creation failed (HTTP ${response.code}): $body"))
                }
                JSONObject(body).optString("id").ifBlank {
                    return@withContext Result.failure(IllegalStateException("Instagram didn't return a container ID."))
                }
            }

            // Step 2: poll until Instagram finishes fetching + processing the video.
            var ready = false
            repeat(20) {
                delay(3000)
                val statusUrl = "https://graph.facebook.com/v19.0/$containerId?fields=status_code&access_token=$pageToken"
                okHttpClient.newCall(Request.Builder().url(statusUrl).build()).execute().use { response ->
                    if (response.isSuccessful) {
                        val status = JSONObject(response.body?.string().orEmpty()).optString("status_code")
                        when (status) {
                            "FINISHED" -> ready = true
                            "ERROR" -> return@withContext Result.failure(IllegalStateException("Instagram failed to process the video."))
                        }
                    }
                }
            }
            if (!ready) return@withContext Result.failure(IllegalStateException("Instagram is still processing — try publishing again shortly."))

            // Step 3: publish the container.
            val publishForm = FormBody.Builder()
                .add("creation_id", containerId)
                .add("access_token", pageToken)
                .build()
            val publishRequest = Request.Builder()
                .url("https://graph.facebook.com/v19.0/$igUserId/media_publish")
                .post(publishForm)
                .build()

            okHttpClient.newCall(publishRequest).execute().use { response ->
                val body = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(IllegalStateException("Instagram publish failed (HTTP ${response.code}): $body"))
                }
                val mediaId = JSONObject(body).optString("id")
                if (mediaId.isBlank()) {
                    Result.failure(IllegalStateException("Publish succeeded but Instagram returned no media ID."))
                } else {
                    Result.success("Instagram media id: $mediaId")
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
