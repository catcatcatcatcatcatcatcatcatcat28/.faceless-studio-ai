package com.facelessstudio.ai.data.repository

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.facelessstudio.ai.domain.model.SocialPlatform
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

data class OAuthTokens(
    val accessToken: String,
    val refreshToken: String?,
    val expiresAtEpochMillis: Long
)

/**
 * Encrypted, per-platform storage for:
 *  - the developer app's Client ID / Client Secret (entered once in Settings, same
 *    "bring your own credentials" pattern as the Gemini API key)
 *  - the access/refresh tokens issued after the user completes OAuth
 *
 * Never store any of this in plain DataStore/SharedPreferences.
 */
@Singleton
class OAuthCredentialsRepository @Inject constructor(
    @ApplicationContext context: Context
) {
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "secure_oauth_store",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveClientCredentials(platform: SocialPlatform, clientId: String, clientSecret: String?) {
        prefs.edit()
            .putString(key(platform, "client_id"), clientId)
            .putString(key(platform, "client_secret"), clientSecret.orEmpty())
            .apply()
    }

    fun clientId(platform: SocialPlatform): String = prefs.getString(key(platform, "client_id"), "").orEmpty()
    fun clientSecret(platform: SocialPlatform): String = prefs.getString(key(platform, "client_secret"), "").orEmpty()
    fun hasClientCredentials(platform: SocialPlatform): Boolean = clientId(platform).isNotBlank()

    fun saveTokens(platform: SocialPlatform, tokens: OAuthTokens) {
        prefs.edit()
            .putString(key(platform, "access_token"), tokens.accessToken)
            .putString(key(platform, "refresh_token"), tokens.refreshToken.orEmpty())
            .putLong(key(platform, "expires_at"), tokens.expiresAtEpochMillis)
            .apply()
    }

    fun tokens(platform: SocialPlatform): OAuthTokens? {
        val access = prefs.getString(key(platform, "access_token"), null) ?: return null
        val refresh = prefs.getString(key(platform, "refresh_token"), null)
        val expiresAt = prefs.getLong(key(platform, "expires_at"), 0L)
        return OAuthTokens(access, refresh?.ifBlank { null }, expiresAt)
    }

    fun clearTokens(platform: SocialPlatform) {
        prefs.edit()
            .remove(key(platform, "access_token"))
            .remove(key(platform, "refresh_token"))
            .remove(key(platform, "expires_at"))
            .apply()
    }

    /** Small per-platform metadata store, e.g. the Facebook Page chosen to post as, or its linked IG business account id. */
    fun saveExtra(platform: SocialPlatform, extraKey: String, value: String) {
        prefs.edit().putString(key(platform, "extra_$extraKey"), value).apply()
    }

    fun extra(platform: SocialPlatform, extraKey: String): String? =
        prefs.getString(key(platform, "extra_$extraKey"), null)

    private fun key(platform: SocialPlatform, suffix: String) = "${platform.name}_$suffix"
}
