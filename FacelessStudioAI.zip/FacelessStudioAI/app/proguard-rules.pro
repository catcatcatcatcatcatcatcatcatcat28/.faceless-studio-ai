# Add project specific ProGuard rules here.
# Keep Retrofit/Gson model classes
-keep class com.facelessstudio.ai.domain.model.** { *; }
-keepattributes Signature
-keepattributes *Annotation*
