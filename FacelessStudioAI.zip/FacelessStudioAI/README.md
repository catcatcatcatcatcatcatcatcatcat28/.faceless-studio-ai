# Faceless Studio AI

A real, working **Android Studio project** (Kotlin + Jetpack Compose + Hilt + Room +
WorkManager + Media3) that generates faceless video content and publishes it directly
to social platforms.

## Important — read this first
I (Claude) cannot generate a compiled `.apk` file directly — there's no Android SDK or
signing setup in this chat environment. What I *can* give you is a complete, correct
source project that builds into an APK in a few clicks via Android Studio, or
automatically via the included GitHub Actions workflow. See "Building" below.

## What's working right now
- **Script generation** — free Gemini API (your own key, no cost)
- **Voiceover** — on-device Android text-to-speech (100% free, no key, works offline)
- **Scene images** — Pollinations.ai (free, no key)
- **Video export** — combines scenes + voiceover into a real MP4 via Media3 Transformer
- **Trend Discovery** — pulls live trending topics from Google Trends + Reddit, tap one
  to use it as your video's topic
- **Direct publishing** (real API calls, not mocks):
  - **YouTube** — full OAuth + resumable Data API v3 upload
  - **TikTok** — full OAuth + Content Posting API upload
  - **Facebook** — full OAuth + Page video upload (multipart, straight from the exported file)
  - **Instagram** — full OAuth + Content Publishing API, but see the limitation below
- **Scheduling** — pick a future date/time for YouTube, TikTok, or Facebook; a
  WorkManager job publishes automatically even if the app is closed, with a notification
  when it succeeds or fails
- **Settings → Connected Accounts** — each platform has its own connect/disconnect and
  its own publishing preferences (auto-publish, visibility, watermark)

### Instagram's one real limitation
This is a genuine restriction of Instagram's API itself, not something missing from this
app: the Content Publishing API only accepts a `video_url` it can reach over the public
internet — it cannot receive an uploaded file directly from a device, the way YouTube,
TikTok, and Facebook can. So Instagram publishing lives under its platform settings screen
as **"Publish (Advanced)"**: export your video, host it somewhere public (a storage bucket,
CDN, etc.), then paste that URL in to publish. There's no way around this without Meta
changing their API.

## Still to build
Timeline editor (reordering/trimming scenes), Threads + Pinterest upload, Analytics,
Subscriptions/billing, Backup & Restore, Appearance & Security settings pages.

## One-time setup before you can use each feature

### Script generation (required first)
1. Go to **aistudio.google.com/app/apikey** → sign in with Google → **Create API Key** (free, no card)
2. In the app: **Settings → AI & Content Safety** → paste it → **Save Key**

### Publishing to a platform (optional, do this per platform you want)
Each platform requires you to register your own free developer app and get a Client ID
(some also need a Client Secret). This app never ships shared credentials — it's the same
"bring your own keys" pattern as the Gemini key, and it's how you stay under each
platform's free tier with your own quota.

| Platform | Where to register | Redirect URI to set there |
|---|---|---|
| YouTube | console.cloud.google.com → enable "YouTube Data API v3" → OAuth Client ID (Android or Web type) | `facelessstudio://oauth-callback` |
| TikTok | developers.tiktok.com → create an app → Login Kit + Content Posting API | `facelessstudio://oauth-callback` |
| Facebook / Instagram | developers.facebook.com → create an app → add "Facebook Login" | `facelessstudio://oauth-callback` |

In the app: **Settings → Connected Accounts → [platform] → Developer App Credentials** →
paste the Client ID / Secret → **Connect [Platform]**. This opens the platform's real
login/consent screen in a Custom Tab.

**Note on Facebook/Instagram App Review:** Meta requires app review before permissions like
`pages_manage_posts` or `instagram_content_publish` work for anyone besides you (the app's
own developer/tester account). Testing with your own account works immediately; letting
other people connect their accounts requires submitting your app for Meta's review first.

### Facebook — choosing which Page to post to
After connecting, go to **Settings → Connected Accounts → Facebook → Choose Page** and
pick which Facebook Page to publish to. If that Page has an Instagram Business Account
linked, Instagram publishing uses that same connection automatically.

## Building

### Option A — Android Studio (Run directly on your device)
1. Install Android Studio (free): developer.android.com/studio
2. **Open** → select this `FacelessStudioAI` folder → let it sync
3. Plug in your phone/tablet (USB debugging on) → click **Run ▶**

### Option B — Android Studio (produce a shareable APK file)
**Build → Build App Bundle(s) / APK(s) → Build APK(s)** → click "locate" in the
notification → transfer `app-debug.apk` to your device → install (allow "install
unknown apps" when prompted).

### Option C — GitHub Actions (no computer needed, builds in the cloud)
This repo includes `.github/workflows/build-apk.yml`. Push this project to a GitHub repo
(uploading the whole folder, or this zip — the workflow unzips it automatically if it
finds one at the repo root) → check the **Actions** tab → download the built APK from
the **Artifacts** section once the run finishes (green check).

## Architecture notes
- MVVM + Hilt throughout; all API keys/tokens live in `EncryptedSharedPreferences`, never
  plain storage
- OAuth uses Authorization Code + PKCE where the platform supports it, launched via
  Custom Tabs, redirected back through the `facelessstudio://oauth-callback` deep link
- Scheduled publishing runs through `WorkManager` + Hilt's `HiltWorkerFactory`, so it
  survives app restarts and works while the app is closed
